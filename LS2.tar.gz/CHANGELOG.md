Change Logs
==

v2.0.0.4 (Apr 14, 2015)
--
#### Feature Enhancements & Changes
- Changed to use error code `406-02` for removing an organization that has already been removed
- Updated APIs on getting license info & logs when license migration involved

v2.0.0.3 (Apr 8, 2015)
--
#### Bug Fixings
- Amended to use error code `406-10` for deducting state rather than `406-01`

#### Feature Enhancements
- Filtered the bill which has empty `po_number` in API get-obu-bills
- Added `billing_time` for deduction license logs in API get-license-logs

v2.0.0.2 (Apr 7, 2015)
--
#### Bug Fixings
- Fixed a bug that cannot unregister device when organization is exhausted.

#### Feature Enhancements & Changes
- Allow updating organization only in `normal` or `exhausted` state
- Deduction through table `device_log`

v2.0.0.1 (Mar 27, 2015)
--
#### Bug Fixings
- Fixed bug that server stopped working when migrated license exceeding 10 times

#### Feature Enhancements
- Improved on writing diagnostic logs

v2.0.0.0 (Mar 20, 2015)
--
#### Announcements
- Pleased to release

v2.0.0.0-beta.8 (Mar 19, 2015)
--
#### Feature Enhancements & Changes
- Improved deduction module to avoid race condition with API calls
- Changed `api_log.rtime` to use second as unit

v2.0.0.0-beta.7 (Mar 18, 2015)
--
#### Bug Fixings
- Minor fixings in get-bills

#### Feature Enhancements
- Added `billing_log` in database to enhance stability and issue analysis for deduction module

v2.0.0.0-beta.6 (Mar 13, 2015)
--
#### Feature Enhancements
- Improved some error messages
- Enhanced checks on API `get-bills`
- Added constraints on API `import-licenses` to only allow `DHQ` to access
- Modified table column name according to database schema

v2.0.0.0-beta.5 (Mar 12, 2015)
--
#### Bug Fixings
- Fixed a typo which caused incorrect error messages on API get-device-log

#### Feature Enhancements & Changes
- Improved error messages when unregister non-existing devices
- Improved deducting module by removing some unnecessary code
- Changed API get-device-log that user must specify `date` in URL (no default value for `date`)

v2.0.0.0-beta.4 (Mar 11, 2015)
--
#### Bug Fixings
- Fixed bug that no `points` in response json when get obu bills

#### Feature Enhancements
- Added checks on license deposit/import APIs to ensure that license-id must be 20-char length
- Improve code on generating error messages

v2.0.0.0-beta.3 (Mar 10, 2015)
--
#### Bug Fixings
- Fixed some typos which might cause crash
- Fixed issue of incorrect organization state (exhausted -> normal) after migrate/erase license 

#### Feature Enhancements
- Changed to use empty string for `expiration` to denote license has no due date
- Added a new error code for license migration (organizations not in same OBU)
- Enhanced syntax check that group type must be `obu` or `msp` when create organization
- Added error message for `406-14`

v2.0.0.0-beta.2 (Mar 9, 2015)
--
#### Bug Fixings
- Fixed bug which might crash on unregistering device
- Resolved issue that device cannot be registered while query-license-info shows enough points

#### Feature Enhancements
- Introduced logs for diagnostic purposes
- Improved the format of `timezone`. e.g. +08:00

v2.0.0.0-beta (Mar 6, 2015)
--
#### Bug Fixings
- Cannot migrate licenses
- Cannot erase licenses
- License info/log shows invalid date-time format
- Expiration shows '""' on unregister device 
- Wrong response on register device when `is_perform` equals false
- Organization becomes `normal` while not deposited license

v2.0.0.0-alpha.2 (Mar 4, 2015)
-- 
#### Bug Fixings
- Invalid time-zone in API requests
- Cannot deposit licenses

#### Feature Enhancements
- Added more checks on API syntax
- Improved user authentication
- Improved SQL query

v2.0.0.0-alpha (Feb 26, 2015)
--
#### Feature Enhancements
- Initial complete with APIs:
	- Organizations (create, delete, info, log)
	- Devices (register, unregister)
	- Licenses (deposit, erase, migrate, import, info, log)
	- Billing log
