<?php
    require_once("lib/Thread.php");
    require_once("lib/restclient.php");
    
    // set thread count and execution times
    $thread_count = 100;
    $execute_count_in_one_thread = 10;

    // set the organization name you want to test
    $org_name="testorg01-1";
    
    // set your ip address of api
    $api = new RestClient(array('base_url' => "http://localhost/api/v1",'format' => "json"));
    
    // curl data from license server api
    $api->set_option('curl_options',array(CURLOPT_SSL_VERIFYPEER=>0, CURLOPT_USERPWD=>"DJP:yhUMAXaSY8Aj"));
 
    // function to be ran on separate threads
    function paralel( $_limit, $_name ) {
        for ( $index = 0; $index < $_limit; $index++ ) {
            global $api, $org_name;
            echo 'Now running thread ' . $_name . PHP_EOL;
            $result = $api->get("organization/".$org_name."/");
            if($result->info->http_code == 200){

                //print_r($result->decode_response());
                $org_result = $result->offsetGet("organization");
                //print_r($org_result);

                $current_point = $org_result->points;
                print_r("current points:".$current_point."\n");
                $expense_point = floor($org_result->expense_per_unit);
                print_r("expense points:".$expense_point."\n");
                $remaining_point = floor($current_point - $expense_point);
                print_r("remaining points:".$remaining_point."\n");

            }else{
                print_r($result->info->http_code."\n");
            }
            
            sleep( 1 );
        }
    }
    
    $t_array = array();

    // create thread objects
    for ($x = 0; $x < $thread_count; $x++)
    {
        $t_array[] = new Thread( 'paralel' );

        // start them
        $t_array[$x]->start( $execute_count_in_one_thread, 't'.$x );
    }
 
    // keep the program running until the threads finish
    while( 1 ) {
        $isAnyThreadAlive = false;
        for ($i = 0; $i < $thread_count; $i++)
        {
            if($t_array[$i]->isAlive()){
                $isAnyThreadAlive = true;
                break;
            }
        }
        if($isAnyThreadAlive == false){
            break;
        }
    }
?>