var express = require('express');
var bodyParser = require('body-parser');
var passport = require('passport');
var database = require('../lib/database');
var utility = require('../lib/utility');
var ecode = require('../lib/error-code');
var router = express.Router();
var jsonParser = bodyParser.json();
var auth = require('../models/auth');
var organzationOper = require('../models/organization');
var billsOper = require('../models/bills');
var apiDepositLicense = require('../models/license-deposit');
var apiLicenseInfo = require('../models/license-info');
var apiLicenseLog = require('../models/license-log');
var apiMigrateLicense = require('../models/license-migrate');
var apiEraseLicense = require('../models/license-erase');
var apiServerStatus = require('../models/server-status');
var apiServerVersion = require('../models/server-version');
var apiGenerateLicense = require('../models/license-generate');
var deviceObj = require('../models/device');
var diagMod = require('../lib/log');


router.post('/organization/:orgId/devices', passport.authenticate('basic', {session: false}), auth.doAuthCall, function (req, res) {
  var organizationName = req.params.orgid;
  var retMessage;
  diagMod.debugLog('register-device', 'get organization_id information:' + organizationName);
  res.set('Content-Type', 'application/json');
  var startTime = new Date().getTime();
  console.log(startTime);

  var recordObj = {
    requestUrl: "url",
    requestMethod: "method",
    requestParams: "rq params",
    responseParams: "rs params",
    appId: "id",
    requestIp: "0.0.0.0",
    rtime: 12321332,//timediff
    authorized: 1,
    error: 0
  };
  recordObj.requestUrl = req.originalUrl;
  recordObj.requestMethod = req.method;
  recordObj.appId = req.user;
  recordObj.requestIp = req.hostname;
  if (req.body.requests == undefined) {
    recordObj.requestParams = "";
  } else {
    recordObj.requestParams = JSON.stringify(req.body);
  }
  diagMod.debugLog('register-device', 'register device start');
  deviceObj.registerDevice(req, function (type, code, content, resource, value) {
    var endTime = new Date().getTime();
    console.log(endTime);
    var diff = endTime - startTime;
    recordObj.rtime = diff;
    recordObj.error = content.substr(0, 3);
    var strJson = utility.stringifyJsonObj(ecode.showErrorResponse(type, code, content, resource, value), req.query.pretty);
    recordObj.responseParams = strJson;
    utility.recordApiLog(recordObj);
    res.status(content.substr(0, 3)).end(strJson);
    diagMod.debugLog('register-device', 'register device end');
  });
});

router.delete('/organization/:orgId/devices', passport.authenticate('basic', {session: false}), auth.doAuthCall, function (req, res) {
  var organizationName = req.params.orgId;
  var retMessage;
  diagMod.debugLog('unregister-device', 'unregister device start');
  res.set('Content-Type', 'application/json');
  var startTime = new Date().getTime();
  console.log(startTime);

  var recordObj = {
    requestUrl: "url",
    requestMethod: "method",
    requestParams: "rq params",
    responseParams: "rs params",
    appId: "id",
    requestIp: "0.0.0.0",
    rtime: 12321332,//timediff
    authorized: 1,
    error: 0
  };
  recordObj.requestUrl = req.originalUrl;
  recordObj.requestMethod = req.method;
  recordObj.appId = req.user;
  recordObj.requestIp = req.hostname;
  if (req.body.requests == undefined) {
    recordObj.requestParams = "";
  } else {
    recordObj.requestParams = JSON.stringify(req.body);
  }
  console.log('unRegister device start');
  diagMod.debugLog('unregister-device', 'unregister device start');
  deviceObj.unRegisterDevice(req, function (type, code, content, resource, value) {
    var endTime = new Date().getTime();
    console.log(endTime);
    var diff = endTime - startTime;
    recordObj.rtime = diff;
    recordObj.error = content.substr(0, 3);
    var strJson = utility.stringifyJsonObj(ecode.showErrorResponse(type, code, content, resource, value), req.query.pretty);
    recordObj.responseParams = strJson;
    utility.recordApiLog(recordObj);
    res.status(content.substr(0, 3)).end(strJson);
    diagMod.debugLog('unregister-device', 'unregister device end');
  });
});

router.get('/organization/:orgId/devices/logs/:date', passport.authenticate('basic', {session: false}), auth.doAuthCall, function (req, res) {
  var organizationName = req.params.orgId;
  var retMessage;
  diagMod.debugLog('get-device-logs', 'get organization_id information:' + organizationName);
  res.set('Content-Type', 'application/json');
  var startTime = new Date().getTime();
  console.log(startTime);

  var recordObj = {
    requestUrl: "url",
    requestMethod: "method",
    requestParams: "rq params",
    responseParams: "rs params",
    appId: "id",
    requestIp: "0.0.0.0",
    rtime: 12321332,//timediff
    authorized: 1,
    error: 0
  };
  recordObj.requestUrl = req.originalUrl;
  recordObj.requestMethod = req.method;
  recordObj.appId = req.user;
  recordObj.requestIp = req.hostname;
  if (req.body.requests == undefined) {
    recordObj.requestParams = "";
  } else {
    recordObj.requestParams = JSON.stringify(req.body);
  }
  diagMod.debugLog('get-device-logs', 'get devices log start');
  deviceObj.getDevicesLog(req, function (type, code, content, resource, value) {
    var endTime = new Date().getTime();
    console.log(endTime);
    var diff = endTime - startTime;
    recordObj.rtime = diff;
    recordObj.error = content.substr(0, 3);
    var strJson = utility.stringifyJsonObj(ecode.showErrorResponse(type, code, content, resource, value), req.query.pretty);
    recordObj.responseParams = strJson;
    utility.recordApiLog(recordObj);
    res.status(content.substr(0, 3)).end(strJson);
    diagMod.debugLog('get-device-logs', 'get devices log end');
  });
});

router.post('/organization', passport.authenticate('basic', {session: false}), auth.doAuthCall, function (req, res) {
  var startTime = new Date().getTime();
  res.set('Content-Type', 'application/json');
  var errorMessage;
  var recordObj = {
    requestUrl: "url",
    requestMethod: "method",
    requestParams: "rq params",
    responseParams: "rs params",
    appId: "id",
    requestIp: "0.0.0.0",
    rtime: 12321332,//timediff
    authorized: 1,
    error: 0
  };
  recordObj.requestUrl = req.originalUrl;
  recordObj.requestMethod = req.method;
  recordObj.appId = req.user;
  recordObj.requestIp = req.hostname;
  if (req.body.requests == undefined) {
    recordObj.requestParams = "";
  } else {
    recordObj.requestParams = JSON.stringify(req.body);
  }
  var jsonData = req.body.requests;
  if (jsonData == null || jsonData == undefined) {
    var endTime = new Date().getTime();
    var diff = endTime - startTime;
    recordObj.rtime = diff;
    recordObj.error = ecode.code.BAD_REQUEST;
    errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(0, "false", "400-01"), req.query.pretty);
    recordObj.responseParams = errorMessage;
    utility.recordApiLog(recordObj);
    res.status(ecode.code.BAD_REQUEST).end(errorMessage);
    return;
  }
  var len = jsonData.length;
  if (len != 1) {
    var endTime = new Date().getTime();
    var diff = endTime - startTime;
    recordObj.rtime = diff;
    recordObj.error = ecode.code.BAD_REQUEST;
    errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(0, "false", "400-01"), req.query.pretty);
    recordObj.responseParams = errorMessage;
    utility.recordApiLog(recordObj);
    res.status(ecode.code.BAD_REQUEST).end(errorMessage);
    return;
  }
  var organization = jsonData[0].organization_id;
  var belongsName = jsonData[0].belongs_to_name;
  var belongsType = jsonData[0].belongs_to_type;
  var timeZone = jsonData[0].time_zone;

  if (!(organization && belongsName && belongsType && timeZone) || (belongsType != 'obu' && belongsType != 'msp')) {
    var endTime = new Date().getTime();
    var diff = endTime - startTime;
    recordObj.rtime = diff;
    recordObj.error = ecode.code.BAD_REQUEST;
    if (organization) {
      errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(1, "false", "400-01", "", organization), req.query.pretty);
    } else {
      errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(0, "false", "400-01"), req.query.pretty);
    }
    recordObj.responseParams = errorMessage;
    utility.recordApiLog(recordObj);
    res.status(ecode.code.BAD_REQUEST).end(errorMessage);
    return;
  }
  var objTimeZone = {tzone: timeZone};
  var timeZoneCorrect = utility.checkandFormatTimeZone(objTimeZone);
  if (!timeZoneCorrect) {
    var endTime = new Date().getTime();
    var diff = endTime - startTime;
    recordObj.rtime = diff;
    recordObj.error = ecode.code.BAD_REQUEST;
    errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(1, "false", "400-01", "", organization), req.query.pretty);
    recordObj.responseParams = errorMessage;
    utility.recordApiLog(recordObj);
    res.status(ecode.code.BAD_REQUEST).end(errorMessage);
    return;
  }
  organzationOper.createOrganization(organization, belongsType, belongsName, objTimeZone.tzone, function (operate, code, content, resource, value) {
    if (operate == "false") {
      var endTime = new Date().getTime();
      var diff = endTime - startTime;
      recordObj.rtime = diff;
      recordObj.error = code;
      errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(1, "false", content, resource, value), req.query.pretty);
      recordObj.responseParams = errorMessage;
      utility.recordApiLog(recordObj);
      res.status(code).end(errorMessage);
    } else if (operate == "true") {
      var endTime = new Date().getTime();
      var diff = endTime - startTime;
      recordObj.rtime = diff;
      recordObj.error = ecode.code.CREATED;
      recordObj.responseParams = "";
      utility.recordApiLog(recordObj);
      res.status(ecode.code.CREATED).end(ecode.showErrorResponse(0, "true"));
    }
  });
});

router.delete('/organization/:organization_id', passport.authenticate('basic', {session: false}), auth.doAuthCall, function (req, res) {
  res.set('Content-Type', 'application/json');
  var startTime = new Date().getTime();
  var errorMessage;
  var recordObj = {
    requestUrl: "url",
    requestMethod: "method",
    requestParams: "rq params",
    responseParams: "rs params",
    appId: "id",
    requestIp: "0.0.0.0",
    rtime: 12321332,//timediff
    authorized: 1,
    error: 0
  };
  recordObj.requestUrl = req.originalUrl;
  recordObj.requestMethod = req.method;
  recordObj.appId = req.user;
  recordObj.requestIp = req.hostname;
  if (req.body.requests == undefined) {
    recordObj.requestParams = "";
  } else {
    recordObj.requestParams = JSON.stringify(req.body);
  }
  var organizationName = req.params.organization_id;
  organzationOper.deleteOrganization(organizationName, function (operate, code, content, resource, value) {
    if (operate == "false") {
      var endTime = new Date().getTime();
      var diff = endTime - startTime;
      recordObj.rtime = diff;
      recordObj.error = code;
      errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(1, "false", content, resource, value), req.query.pretty);
      recordObj.responseParams = errorMessage;
      utility.recordApiLog(recordObj);
      res.status(code).end(errorMessage);
    } else if (operate == "true") {
      var endTime = new Date().getTime();
      var diff = endTime - startTime;
      recordObj.rtime = diff;
      recordObj.error = ecode.code.SUCCEED;
      recordObj.responseParams = "";
      utility.recordApiLog(recordObj);
      res.status(ecode.code.SUCCEED).end(ecode.showErrorResponse(0, "true"));
    }
  });
});

router.post('/organization/:organization_id', passport.authenticate('basic', {session: false}), auth.doAuthCall, function (req, res) {
  var organizationName = req.params.organization_id;
  var errorMessage;
  res.set('Content-Type', 'application/json');
  var startTime = new Date().getTime();
  var recordObj = {
    requestUrl: "url",
    requestMethod: "method",
    requestParams: "rq params",
    responseParams: "rs params",
    appId: "id",
    requestIp: "0.0.0.0",
    rtime: 12321332,//timediff
    authorized: 1,
    error: 0
  };
  recordObj.requestUrl = req.originalUrl;
  recordObj.requestMethod = req.method;
  recordObj.appId = req.user;
  recordObj.requestIp = req.hostname;
  if (req.body.requests == undefined) {
    recordObj.requestParams = "";
  } else {
    recordObj.requestParams = JSON.stringify(req.body);
  }
  var jsonData = req.body.requests;
  if (jsonData == null || jsonData == undefined) {
    var endTime = new Date().getTime();
    var diff = endTime - startTime;
    recordObj.rtime = diff;
    recordObj.error = ecode.code.BAD_REQUEST;
    errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(1, "false", "400-01", "", organizationName), req.query.pretty);
    recordObj.responseParams = errorMessage;
    utility.recordApiLog(recordObj);
    res.status(ecode.code.BAD_REQUEST).end(errorMessage);
    return;
  }
  var len = jsonData.length;
  if (len != 1) {
    var endTime = new Date().getTime();
    var diff = endTime - startTime;
    recordObj.rtime = diff;
    recordObj.error = ecode.code.BAD_REQUEST;
    errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(1, "false", "400-01", "", organizationName), req.query.pretty);
    recordObj.responseParams = errorMessage;
    utility.recordApiLog(recordObj);
    res.status(ecode.code.BAD_REQUEST).end(errorMessage);
    return;
  }
  var organizationState = jsonData[0].state;
  var organizationTimezone = jsonData[0].time_zone;
  if (organizationState == null || organizationState == undefined) {
    if (organizationTimezone == null || organizationTimezone == undefined) {
      var endTime = new Date().getTime();
      var diff = endTime - startTime;
      recordObj.rtime = diff;
      recordObj.error = ecode.code.BAD_REQUEST;
      errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(1, "false", "400-01", "", organizationName), req.query.pretty);
      recordObj.responseParams = errorMessage;
      utility.recordApiLog(recordObj);
      res.status(ecode.code.BAD_REQUEST).end(errorMessage);
      return;
    } else {
      //verify timezone
      var objTimeZone = {tzone: organizationTimezone};
      var timeZoneCorrect = utility.checkandFormatTimeZone(objTimeZone);
      if (!timeZoneCorrect) {
        var endTime = new Date().getTime();
        var diff = endTime - startTime;
        recordObj.rtime = diff;
        recordObj.error = ecode.code.BAD_REQUEST;
        errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(1, "false", "400-01", "", organizationName), req.query.pretty);
        recordObj.responseParams = errorMessage;
        utility.recordApiLog(recordObj);
        res.status(ecode.code.BAD_REQUEST).end(errorMessage);
        return;
      }
      //end verify timezone
      organzationOper.updateOrganization(organizationName, objTimeZone.tzone, function (operate, code, content, resource, value) {
        if (operate == "false") {
          var endTime = new Date().getTime();
          var diff = endTime - startTime;
          recordObj.rtime = diff;
          recordObj.error = code;
          errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(1, "false", content, resource, value), req.query.pretty);
          recordObj.responseParams = errorMessage;
          utility.recordApiLog(recordObj);
          res.status(code).end(errorMessage);
        } else if (operate == "true") {
          var endTime = new Date().getTime();
          var diff = endTime - startTime;
          recordObj.rtime = diff;
          recordObj.error = ecode.code.SUCCEED;
          recordObj.responseParams = "";
          utility.recordApiLog(recordObj);
          res.status(ecode.code.SUCCEED).end(ecode.showErrorResponse(0, "true"));
        }
      });
    }
  } else {
    if (organizationState != "normal") {
      var endTime = new Date().getTime();
      var diff = endTime - startTime;
      recordObj.rtime = diff;
      recordObj.error = ecode.code.NOT_ACCEPTABLE;
      errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(1, "false", "406-03", organizationState, organizationName), req.query.pretty);
      recordObj.responseParams = errorMessage;
      utility.recordApiLog(recordObj);
      res.status(ecode.code.NOT_ACCEPTABLE).end(errorMessage);
      return;
    }
    organzationOper.activeOrganization(organizationName, function (operate, code, content, resource, value) {
      if (operate == "false") {
        var endTime = new Date().getTime();
        var diff = endTime - startTime;
        recordObj.rtime = diff;
        recordObj.error = code;
        errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(1, "false", content, resource, value), req.query.pretty);
        recordObj.responseParams = errorMessage;
        utility.recordApiLog(recordObj);
        res.status(code).end(errorMessage);
      } else if (operate == "true") {
        var endTime = new Date().getTime();
        var diff = endTime - startTime;
        recordObj.rtime = diff;
        recordObj.error = ecode.code.SUCCEED;
        recordObj.responseParams = "";
        utility.recordApiLog(recordObj);
        res.status(ecode.code.SUCCEED).end(ecode.showErrorResponse(0, "true"));
      }
    });
  }
});


router.get('/organization/:organization_id', passport.authenticate('basic', {session: false}), auth.doAuthCall, function (req, res) {

  var organizationName = req.params.organization_id;
  var retMessage;
  res.set('Content-Type', 'application/json');
  var startTime = new Date().getTime();

  var recordObj = {
    requestUrl: "url",
    requestMethod: "method",
    requestParams: "rq params",
    responseParams: "rs params",
    appId: "id",
    requestIp: "0.0.0.0",
    rtime: 12321332,//timediff
    authorized: 1,
    error: 0
  };

  recordObj.requestUrl = req.originalUrl;
  recordObj.requestMethod = req.method;
  recordObj.appId = req.user;
  recordObj.requestIp = req.hostname;
  if (req.body.requests == undefined) {
    recordObj.requestParams = "";
  } else {
    recordObj.requestParams = JSON.stringify(req.body);
  }
  organzationOper.getOrganizationInfo(organizationName, function (operate, code, content, resource, value) {
    recordObj.error = code;
    var endTime = new Date().getTime();
    var diff = endTime - startTime;
    recordObj.rtime = diff;
    if (operate == "false") {
      retMessage = utility.stringifyJsonObj(ecode.showErrorResponse(1, "false", content, resource, value), req.query.pretty);
      recordObj.responseParams = retMessage;
      utility.recordApiLog(recordObj);
      res.status(code).end(retMessage);
    } else if (operate == "true") {
      retMessage = utility.stringifyJsonObj(ecode.showErrorResponse(0, "true", content), req.query.pretty);
      recordObj.responseParams = retMessage;
      utility.recordApiLog(recordObj);
      res.status(code).end(retMessage);
    }
  });
});

router.get('/:obu/bills', passport.authenticate('basic', {session: false}), auth.doAuthCall, function (req, res) {
  var obuName = req.params.obu;
  var retMessage;
  res.set('Content-Type', 'application/json');
  var startTime = new Date().getTime();
  var recordObj = {
    requestUrl: "url",
    requestMethod: "method",
    requestParams: "rq params",
    responseParams: "rs params",
    appId: "id",
    requestIp: "0.0.0.0",
    rtime: 12321332,//timediff
    authorized: 1,
    error: 0
  };
  recordObj.requestUrl = req.originalUrl;
  recordObj.requestMethod = req.method;
  recordObj.appId = req.user;
  recordObj.requestIp = req.hostname;
  if (req.body.requests == undefined) {
    recordObj.requestParams = "";
  } else {
    recordObj.requestParams = JSON.stringify(req.body);
  }
  if (!(req.query.start && req.query.end) || !utility.checkTimeFormat(req.query.start) || !utility.checkTimeFormat(req.query.end) || (utility.getIntervalDays(req.query.start, req.query.end) < 0)) {
    var endTime = new Date().getTime();
    var diff = endTime - startTime;
    recordObj.rtime = diff;
    recordObj.error = ecode.code.BAD_REQUEST;
    retMessage = ecode.errorResponse2("400-01", req.query.pretty);
    recordObj.responseParams = retMessage;
    utility.recordApiLog(recordObj);
    res.status(ecode.code.BAD_REQUEST).end(retMessage);
    return;
  }
  billsOper.getBills(obuName, req.query.start, req.query.end, function (operate, code, content, resource) {
    recordObj.error = code;
    var endTime = new Date().getTime();
    var diff = endTime - startTime;
    recordObj.rtime = diff;
    if (operate == "false") {
      retMessage = ecode.errorResponseWithPara2(content, resource, req.query.pretty);
      //retMessage = utility.stringifyJsonObj(ecode.showErrorResponse(0, "false", content, resource), req.query.pretty);
      recordObj.responseParams = retMessage;
      utility.recordApiLog(recordObj);
      res.status(code).end(retMessage);
    } else if (operate == "true") {
      retMessage = utility.stringifyJsonObj(ecode.showErrorResponse(0, "true", content), req.query.pretty);
      recordObj.responseParams = retMessage;
      utility.recordApiLog(recordObj);
      res.status(code).end(retMessage);
    }
  });
});

// Import licenses to license-repository
router.post('/:obu/licenses',
  passport.authenticate('basic', {session: false}),
  auth.doAuthCall,
  apiGenerateLicense);

// Deposit license
router.post('/organization/:orgId/licenses',
  passport.authenticate('basic', {session: false}),
  auth.doAuthCall,
  apiDepositLicense);

// Get license change log
router.get('/organization/:orgId/licenses/:licId/logs',
  passport.authenticate('basic', {session: false}),
  auth.doAuthCall,
  apiLicenseLog.apiGetLicenseLogSingle);

router.get('/organization/:orgId/licenses/logs',
  passport.authenticate('basic', {session: false}),
  auth.doAuthCall,
  apiLicenseLog.apiGetLicenseLog);

// Get license info
router.get('/organization/:orgId/licenses/:licId',
  passport.authenticate('basic', {session: false}),
  auth.doAuthCall,
  apiLicenseInfo.apiGetLicenseInfoSingle);

router.get('/organization/:orgId/licenses',
  passport.authenticate('basic', {session: false}),
  auth.doAuthCall,
  apiLicenseInfo.apiGetLicenseInfo);

// Migrate license
router.put('/organization/:orgId/licenses/:licId',
  passport.authenticate('basic', {session: false}),
  auth.doAuthCall,
  apiMigrateLicense);

// Erase license
router.delete('/organization/:orgId/licenses/:licId',
  passport.authenticate('basic', {session: false}),
  auth.doAuthCall,
  apiEraseLicense);

// GET server status
router.get('/server/status',
//  passport.authenticate('basic', {session: false}),
  apiServerStatus);

// GET server version
router.get('/server/version',
//  passport.authenticate('basic', {session: false}),
  apiServerVersion);


// CATCH others that not correctly routed, WILL NOT write API LOG here
router.use(function (req, res, next) {
  if (utility.routeSupported(req.url)) { // routes which we support, but the method not accepted
    res.set('Content-Type', 'application/json');
    res
      .status(ecode.code.METHOD_NOT_ALLOWED)
      .end(ecode.errorResponseWithPara('405-01', req.method, req.query.pretty));
  } else {
    next(); // let it fall into 404
  }
});

module.exports = router;
