var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var database = require('./lib/database');
var utility = require('./lib/utility');
var ecode = require('./lib/error-code');
var routes = require('./routes/index');
var passport = require('passport');
var BasicStrategy = require('passport-http').BasicStrategy;
var auth = require('./models/auth');
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');


// uncomment after placing your favicon in /public
//app.use(favicon(__dirname + '/public/favicon.ico'));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(cookieParser());
app.use(passport.initialize());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/v1/', routes);


passport.use(new BasicStrategy(
  function (username, password, done) {
    // check authentication from auth table in database
    auth.verifyAuth(username, password, function (isFound) {
      if (isFound == 200) {
        done(null, username);
      } else if (isFound == 401) {
        done(null, ecode.code.UNAUTHORIZED);
      } else if (isFound == 42002) {
        done(null, 42002);
      } else if (isFound == 42001) {
        done(null, 42001);
      }
    });
  }
));

// catch 404 and forward to error handler
// DO NOT write API log, since it's not an API call
app.use(function (req, res, next) {
  res.set('Content-Type', 'application/json');
  res
    .status(ecode.code.NOT_FOUND)
    .end(ecode.errorResponseWithPara2('404-01', req.originalUrl, req.query.pretty));

  next();
});


// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function (err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function (err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});

module.exports = app;
