//
// Get license server status
//
var database = require('../lib/database');
var utility = require('../lib/utility');
var ecode = require('../lib/error-code');

// perform operation to get working status
function apiDoServerStatus(req, callback) {
  database.pool.getConnection(function (err, sql) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, utility.stringifyJsonObj({
        status: 'error',
        errors: {
          code: '420-02',
          messages: 'Method Failure. The database is disconnected'
        }
      }, req.query.pretty));
    } else {
      sql.release();
      callback(ecode.code.SUCCEED, utility.stringifyJsonObj({
        status: 'ok'
      }, req.query.pretty));
    }
  });
}

// API - get server/DB working status
function apiServerStatus(req, res) {
  var startTime = new Date().getTime();
  var apiLog = {
    requestUrl: req.originalUrl,
    requestMethod: req.method,
    appId: '', //req.user, /* no user-auth required */
    requestIp: req.hostname,
    authorized: 1,
    error: 200,
    rtime: 0,
    requestParams: '',
    responseParams: ''
  };

  if (req.body.requests !== undefined) {
    apiLog.requestParams = JSON.stringify(req.body);
  }

  res.set('Content-Type', 'application/json');
  apiDoServerStatus(req, function (errStatus, resText) {
    res.status(errStatus).end(resText);
    apiLog.rtime = new Date().getTime() - startTime;
    apiLog.error = errStatus;
    apiLog.responseParams = resText;
    utility.recordApiLog(apiLog);
  });
}

module.exports = apiServerStatus;
