var database = require('../lib/database');
var ecode = require('../lib/error-code');
var sqlScript = require('../lib/sql-statements');
var logDebug = require('../lib/log');

function getBills(obuName, startTime, endTime, callback) {
  database.pool.getConnection(function (err, connection) {
    if (err) {
      logDebug.errorLog("bill.js", "POOL ==->" + err);
      callback("false", ecode.code.METHOD_FAILURE, "420-02", "get bills");
    } else {
      var sql;
      sql = sqlScript.checkObuinLicenseRepository(obuName);
      logDebug.debugLog("bills.js", sql);
      connection.query(sql, function (err, result) {
        if (err) {
          logDebug.errorLog("bill.js", "the sql execute error");
          connection.release();
          callback("false", ecode.code.METHOD_FAILURE, "420-01", "get bills");
        } else {
          if (result.length <= 0) {//null
            var errorMsg;
            errorMsg = "api/v1/";
            errorMsg += obuName;
            errorMsg += "/bills";
            connection.release();
            callback("false", ecode.code.NOT_FOUND, "404-01", errorMsg);
          } else {
            sql = sqlScript.getBillsLog(obuName, startTime, endTime);
            logDebug.debugLog("bill.js", sql);
            connection.query(sql, function (err, result) {
              if (err) {
                logDebug.errorLog("bill.js", "the sql execute error");
                connection.release();
                callback("false", ecode.code.METHOD_FAILURE, "420-01", "get bills");
              } else {
                if (result.length == 0) {//null
                  var resJson = {
                    "success": "true",
                    "bills": {}
                  };
                  connection.release();
                  callback("true", ecode.code.SUCCEED, resJson);
                } else {
                  var jsonArray = new Array();
                  var resJson = {
                    "success": "true",
                    "bills": {}
                  };
                  for (var i = 0; i < result.length; i++) {
                    var bills = {};
                    bills['license_key'] = result[i].license_id;
                    bills['points'] = result[i].change_point;
                    bills['pk_number'] = result[i].po_number;
                    bills['update_time'] = result[i].last_update.formatAsUTC("yyyy-MM-dd hh:mm:ss") + " +00:00";
                    jsonArray.push(bills);
                  }
                  resJson.bills = jsonArray;
                  logDebug.debugLog("bill.js", JSON.stringify(resJson));
                  connection.release();
                  callback("true", ecode.code.SUCCEED, resJson);
                }
              }
            });
          }
        }
      });
    }
  });
}

module.exports.getBills = getBills;
