//
// API - Migrate license
//
var database = require('../lib/database');
var utility = require('../lib/utility');
var ecode = require('../lib/error-code');
var sqlScript = require('../lib/sql-statements');
var diagMod = require('../lib/log');

// check whether the format of posted data is valid
function checkRequestFormat(requests) {
  for (var i = 0; i < requests.length; i++) {
    if (requests[i].organization_id == undefined
      || requests[i].organization_id.constructor != String
      || requests[i].organization_id.length <= 0) {
      return false;
    }
  }

  // ONLY one element allowed
  if (requests.length != 1) {
    return false;
  }

  return true;
}

// commit changes on migrating license
function doCommitChanges(req, sql, callback) {
  sql.commit(function (err) {
    if (err) {
      sql.rollback(function () {
      });
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Migrate License', req.query.pretty));
      sql.release();
    } else {
      diagMod.debugLog('migrate-license', 'Migrate license success.');
      callback(ecode.code.SUCCEED, ''); // empty on success
      sql.release();
    }
  });
}

// write logs about license migration
function doLogMigrateLicense(req, sql, callback) {
  var script = sqlScript.insertMigrateLicenseLog(req.params.orgIdIntSrc,
    req.params.orgIdIntDest, req.params.licId, req.params.licRemainingPoints);
  diagMod.debugLog('migrate-license', 'SQL: ' + script);
  sql.query(script, function (err, result) {
    if (err) {
      sql.rollback(function () {
      });
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Migrate License', req.query.pretty));
      sql.release();
    } else {
      doCommitChanges(req, sql, callback);
    }
  });
}

// migrate license from one organization to another
function doMigrateLicense(req, sql, callback) {
  var script = sqlScript.migrateLicenseBetweenOrganizations(req.params.orgIdIntSrc,
    req.params.orgIdIntDest, req.params.licId);
  diagMod.debugLog('migrate-license', 'SQL: ' + script);
  sql.query(script, function (err, result) {
    if (err) {
      sql.rollback(function () {
      });
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Migrate License', req.query.pretty));
      sql.release();
    } else {
      doLogMigrateLicense(req, sql, callback);
    }
  });
}

// do migrate license
function performMigrateLicense(req, sql, callback) {
  sql.beginTransaction(function (err) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Migrate License', req.query.pretty));
      sql.release();
    } else {
      doMigrateLicense(req, sql, callback);
    }
  });
}

// verify that organization has enough points before migrate the license
function verifyLicenseRemainingPoints(req, sql, callback) {
  var script = sqlScript.getOrganizationRemainingPoints(req.params.orgIdIntSrc);
  diagMod.debugLog('migrate-license', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Migrate License', req.query.pretty));
      sql.release();
    } else {
      script = sqlScript.deviceGetDevBudget(req.params.orgIdIntSrc);
      diagMod.debugLog('migrate-license', 'SQL: ' + script);
      sql.query(script, function (err, result) {
        if (err) {
          callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Migrate License', req.query.pretty));
          sql.release();
        } else if (rows[0].totalRemainingPoints - result[0][0].budget_points < req.params.licRemainingPoints) {
          diagMod.debugLog('migrate-license', 'CANNOT migrate! orgTotalRemain: ' + rows[0].totalRemainingPoints + ', budget: '
            + result[0][0].budget_points + ', licenseRemain: ' + req.params.licRemainingPoints);
          callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-14', req.query.pretty));
          sql.release();
        } else {
          performMigrateLicense(req, sql, callback);
        }
      });
    }
  });
}

// ensure license exist (ALSO retrieve remaining-points)
function checkLicenseExistence(req, sql, callback) {
  var script = sqlScript.getLicenseRemainingPoint(req.params.orgIdIntSrc, req.params.licId);
  diagMod.debugLog('migrate-license', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Migrate License', req.query.pretty));
      sql.release();
    } else if (rows.length <= 0) {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponseOnLicenses('406-05', [req.params.licId], req.query.pretty));
      sql.release();
    } else if (rows[0].remaining_point <= 0) { // no points remaining
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-12', req.query.pretty));
      sql.release();
    } else {
      req.params.licRemainingPoints = rows[0].remaining_point;
      if (req.params.orgStateSrc === 'exhausted') { // 如果是Exhausted，则直接可以Migrate。（get_device_budget只能在Normal状态调用）
        performMigrateLicense(req, sql, callback);
      } else {
        verifyLicenseRemainingPoints(req, sql, callback);
      }
    }
  });
}

// ensure the two organizations for license migration are in the same group
function checkOrganizationsForSameGroup(req, sql, callback) {
  var script = sqlScript.checkOrganizationsForSameGroup(req.params.orgIdIntSrc, req.params.orgIdIntDest);
  diagMod.debugLog('migrate-license', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Migrate License', req.query.pretty));
      sql.release();
    } else if (rows[0].count <= 0) {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponseWithTwoPara(
        '406-15', req.params.orgId, req.body.requests[0].organization_id, req.query.pretty));
      sql.release();
    } else {
      checkLicenseExistence(req, sql, callback);
    }
  });
}

// check the destination organization state for license migration
function checkDestOrganizationState(req, sql, callback) {
  var script = sqlScript.getOrganizationState(req.body.requests[0].organization_id);
  diagMod.debugLog('migrate-license', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Migrate License', req.query.pretty));
      sql.release();
    } else if (rows.length <= 0) {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-02', req.query.pretty));
      sql.release();
    } else if (rows[0].state == 'deducting') {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-10', req.query.pretty));
      sql.release();
    } else if (rows[0].state != 'normal' && rows[0].state != 'exhausted') {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-13', req.query.pretty));
      sql.release();
    } else {
      req.params.orgIdIntDest = rows[0].id;
      checkOrganizationsForSameGroup(req, sql, callback);
    }
  });
}

// check the source organization state for license migration
function checkSrcOrganizationState(req, sql, callback) {
  var script = sqlScript.getOrganizationState(req.params.orgId);
  diagMod.debugLog('migrate-license', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Migrate License', req.query.pretty));
      sql.release();
    } else if (rows.length <= 0) {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-02', req.query.pretty));
      sql.release();
    } else if (rows[0].state == 'deducting') {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-10', req.query.pretty));
      sql.release();
    } else if (rows[0].state != 'normal' && rows[0].state != 'exhausted') {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-13', req.query.pretty));
      sql.release();
    } else {
      req.params.orgStateSrc = rows[0].state; // 如果源Org状态是Exhausted，则可以直接Migrate
      req.params.orgIdIntSrc = rows[0].id;
      checkDestOrganizationState(req, sql, callback);
    }
  });
}

// perform migrate license
function apiDoMigrateLicense(req, callback) {
  // check the API syntax
  if (req.body === undefined
    || req.body.requests === undefined
    || !utility.checkContentTypeJson(req.headers['content-type'])
    || !Array.isArray(req.body.requests)
    || !checkRequestFormat(req.body.requests)) {
    callback(ecode.code.BAD_REQUEST, ecode.errorResponse('400-01', req.query.pretty));
    return;
  }

  database.pool.getConnection(function (err, sql) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Migrate License', req.query.pretty));
    } else {
      checkSrcOrganizationState(req, sql, callback);
    }
  });
}

// API: migrate license
function apiMigrateLicense(req, res) {
  var startTime = new Date().getTime();
  var apiLog = {
    requestUrl: req.originalUrl,
    requestMethod: req.method,
    appId: req.user,
    requestIp: req.hostname,
    authorized: 1,
    error: 200,
    rtime: 0,
    requestParams: '',
    responseParams: ''
  };

  if (req.body.requests !== undefined) {
    apiLog.requestParams = JSON.stringify(req.body);
  }

  res.set('Content-Type', 'application/json');
  apiDoMigrateLicense(req, function (errStatus, resText) {
    res.status(errStatus).end(resText);
    apiLog.rtime = new Date().getTime() - startTime;
    apiLog.error = errStatus;
    apiLog.responseParams = resText;
    utility.recordApiLog(apiLog);
  });
}


module.exports = apiMigrateLicense;
