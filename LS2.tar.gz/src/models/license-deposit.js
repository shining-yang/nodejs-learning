//
// API - Deposit licenses
//
var database = require("../lib/database");
var utility = require('../lib/utility');
var ecode = require('../lib/error-code');
var sqlScript = require('../lib/sql-statements');
var diagMod = require('../lib/log');

function buildSuccessResponse(orgName, cycle, req, lic, pretty) {
  var resJson = {
    licenses: []
  };

  for (var i = 0; i < req.length; i++) {
    resJson.licenses.push({
      id: req[i].license_id,
      points: lic[i].points,
      unit: cycle,
      expiration: '', // use empty string to denote no due date
      belongs_to: orgName,
      deposited_by: req[i].deposited_by
    });
  }

  return utility.stringifyJsonObj(resJson, pretty);
}

// check whether the format of posted data is valid
function checkRequestFormat(requests) {
  for (var i = 0; i < requests.length; i++) {
    if (!requests[i].license_id
      || requests[i].license_id.constructor != String
      || requests[i].license_id.length != 20) { // license-id is fixed 20-chars
      return false;
    }

    if (!requests[i].deposited_by
      || requests[i].deposited_by.constructor != String
      || requests[i].deposited_by.length <= 0) {
      return false;
    }
  }

  return true;
}

// Determine if an array contains the specified element
function arrayContains(arr, item) {
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] === item) {
      return true;
    }
  }

  return false;
}

//
function licenseContainsId(rows, id) {
  for (var i = 0; i < rows.length; i++) {
    if (rows[i].license_id === id) {
      return true;
    }
  }

  return false;
}

// Get invalid licenses
function filterInvalidLicenses(requests, rows) {
  var ids = [];
  for (var i = 0; i < requests.length; i++) {
    if (!licenseContainsId(rows, requests[i].license_id)) {
      ids.push(requests[i].license_id);
    }
  }

  return ids;
}

// Get duplicated license ids
function getDuplicateLicenseIds(requests) {
  var idsExisted = [];
  var idsDuplicate = [];
  for (var i = 0; i < requests.length; i++) {
    if (!arrayContains(idsExisted, requests[i].license_id)) {
      idsExisted.push(requests[i].license_id);
    } else {
      if (!arrayContains(idsDuplicate, requests[i].license_id)) {
        idsDuplicate.push(requests[i].license_id);
      }
    }
  }

  return idsDuplicate;
}

// gather all used license-id
function gatherUsedId(rows) {
  var ids = [];
  for (var i = 0; i < rows.length; i++) {
    ids.push(rows[i].id);
  }
  return ids;
}

// deposit licenses
function performDepositLicenses(req, sql, licenses, callback) {
  sql.beginTransaction(function (err) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Deposit License', req.query.pretty));
      sql.release();
    } else {
      // insert into license
      var script = sqlScript.insertDepositLicense(req.params.orgIdInt, req.body.requests, licenses);
      diagMod.debugLog('deposit-license', 'SQL: ' + script);
      sql.query(script, function (err, results) {
        if (err) {
          sql.rollback(function () {
          });
          callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Deposit License', req.query.pretty));
          sql.release();
        } else {
          // insert into license-log
          var script = sqlScript.insertDepositLicenseLog(req.params.orgIdInt, licenses);
          diagMod.debugLog('deposit-license', 'SQL: ' + script);
          sql.query(script, function (err, results) {
            if (err) {
              sql.rollback(function () {
              });
              callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Deposit License', req.query.pretty));
              sql.release();
            } else {
              // get billing cycle (unit)
              var script = sqlScript.getBillingCycle(req.params.orgIdInt);
              diagMod.debugLog('deposit-license', 'SQL: ' + script);
              sql.query(script, function (err, rowsBillingCycle) {
                if (err || (rowsBillingCycle.length != 1)) {
                  sql.rollback(function () {
                  });
                  callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Deposit License', req.query.pretty));
                  sql.release();
                } else {
                  sql.commit(function (err) {
                    if (err) {
                      sql.rollback(function () {
                      });
                      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Deposit License', req.query.pretty));
                      sql.release();
                    } else {
                      diagMod.debugLog('deposit-license', 'Deposit licenses success.');
                      callback(ecode.code.CREATED, buildSuccessResponse(
                        req.params.orgId, rowsBillingCycle[0].cycle,
                        req.body.requests, licenses, req.query.pretty));
                      sql.release();
                    }
                  }); // commit transaction
                }
              }); // get billing cycle
            }
          }); // insert license-log
        }
      }); // insert license
    }
  }); // start transaction
}

// check licenses for existence
function checkLicenseExistence(req, sql, callback) {
  var script = sqlScript.checkLicenseExistence(req.body.requests, req.user);
  diagMod.debugLog('deposit-license', 'SQL: ' + script);
  sql.query(script, function (err, validLicenses) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Deposit License', req.query.pretty));
      sql.release();
    } else if (validLicenses.length != req.body.requests.length) {
      // some specified app_id:licenses does not exist
      var invalidIds = filterInvalidLicenses(req.body.requests, validLicenses);
      diagMod.debugLog('deposit-license', 'Invalid license id: ' + invalidIds);
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponseOnLicenses('406-05', invalidIds, req.query.pretty));
      sql.release();
    } else {
      performDepositLicenses(req, sql, validLicenses, callback);
    }
  });
}

// check if there are some licenses already been used
function checkLicenseUsability(req, sql, callback) {
  var script = sqlScript.checkLicenseUsability(req.body.requests);
  diagMod.debugLog('deposit-license', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Deposit License', req.query.pretty));
      sql.release();
    } else if (rows.length > 0) { // some specified licenses already been used
      var usedIds = gatherUsedId(rows);
      callback(ecode.code.CONFLICT, ecode.errorResponseOnLicenses('409-03', usedIds, req.query.pretty));
      sql.release();
    } else {
      checkLicenseExistence(req, sql, callback);
    }
  });
}

// check organization state
function checkOrganizationState(req, sql, callback) {
  var script = sqlScript.getOrganizationState(req.params.orgId);
  diagMod.debugLog('deposit-license', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Deposit License', req.query.pretty));
      sql.release();
    } else if (rows.length <= 0) {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-02', req.query.pretty));
      sql.release();
    } else if (rows[0].state == 'deducting') {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-10', req.query.pretty));
      sql.release();
    } else if (rows[0].state != 'normal' && rows[0].state != 'exhausted') {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-13', req.query.pretty));
      sql.release();
    } else {
      req.params.orgIdInt = rows[0].id;
      checkLicenseUsability(req, sql, callback);
    }
  });
}

//  do api implementation
function apiDoDepositLicense(req, callback) {
  // check the API syntax
  if (req.body === undefined
    || req.body.requests === undefined
    || !utility.checkContentTypeJson(req.headers['content-type'])
    || !Array.isArray(req.body.requests)
    || !checkRequestFormat(req.body.requests)) {
    callback(ecode.code.BAD_REQUEST, ecode.errorResponse('400-01', req.query.pretty));
    return;
  }

  // check if there are some duplicated requests
  var dupIds = getDuplicateLicenseIds(req.body.requests);
  if (dupIds.length > 0) {
    callback(ecode.code.CONFLICT, ecode.errorResponseOnLicenses('409-04', dupIds, req.query.pretty));
    return;
  }

  // access database
  database.pool.getConnection(function (err, sql) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Deposit License', req.query.pretty));
    } else {
      checkOrganizationState(req, sql, callback);
    }
  });
}

// API: deposit licenses
function apiDepositLicense(req, res) {
  var startTime = new Date().getTime();
  var apiLog = {
    requestUrl: req.originalUrl,
    requestMethod: req.method,
    appId: req.user,
    requestIp: req.hostname,
    authorized: 1,
    error: 200,
    rtime: 0,
    requestParams: '',
    responseParams: ''
  };

  if (req.body.requests !== undefined) {
    apiLog.requestParams = JSON.stringify(req.body);
  }

  res.set('Content-Type', 'application/json');
  apiDoDepositLicense(req, function (errStatus, resText) {
    res.status(errStatus).end(resText);
    apiLog.rtime = new Date().getTime() - startTime;
    apiLog.error = errStatus;
    apiLog.responseParams = resText;
    utility.recordApiLog(apiLog);
  });
}

module.exports = apiDepositLicense;
