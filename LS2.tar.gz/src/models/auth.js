var database = require('../lib/database');
var utility = require('../lib/utility');
var ecode = require('../lib/error-code');
var logDebug = require('../lib/log');


function verifyAuth(userName, password, callback) {
  database.pool.getConnection(function (err, connection) {
    if (err) {
      logDebug.errorLog("auth.js", "POOL auth ==->" + err);
      callback(42002);
    } else {
      connection.query('SELECT 1 FROM auth WHERE app_id=? AND api_key=?', [userName, password], function (err, result) {
        if (err) {
          logDebug.errorLog("auth.js", "the sql execute error:" + err);
          callback(42001);
        } else {
          if (result.length > 0) {
            connection.release();
            callback(200);
          } else {
            connection.release();
            callback(401);
          }
        }
      });
    }
  });
}

// Route callback for user authentication
function doAuthCall(req, res, next) {
  res.set('Content-Type', 'application/json');
  var errorMessage;
  var startTime = new Date().getTime();
  var recordObj = {
    requestUrl: req.originalUrl,
    requestMethod: req.method,
    appId: req.user,
    requestIp: req.hostname,
    authorized: 0, // default to not-authorized
    error: 200,
    rtime: 0,
    requestParams: '',
    responseParams: ''
  };

  if (req.body.requests !== undefined) {
    recordObj.requestParams = JSON.stringify(req.body);
  }

  if (req.user == 401) {
    recordObj.rtime = new Date().getTime() - startTime;
    recordObj.error = 401;
    errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(0, "false", "401-01"), req.query.pretty);
    recordObj.responseParams = errorMessage;
    utility.recordApiLog(recordObj);
    res.status(401).end(errorMessage);
  } else if (req.user == 42001) {
    recordObj.rtime = new Date().getTime() - startTime;
    recordObj.error = 420;
    errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(0, "false", "420-01", "authentication"), req.query.pretty);
    recordObj.responseParams = errorMessage;
    utility.recordApiLog(recordObj);
    res.status(420).end(errorMessage);
  } else if (req.user == 42002) { // database not connected
    errorMessage = utility.stringifyJsonObj(ecode.showErrorResponse(0, "false", "420-02"), req.query.pretty);
    res.status(420).end(errorMessage);
  } else {
    // go further when successfully authenticated
    next();
  }
}

module.exports.verifyAuth = verifyAuth;
module.exports.doAuthCall = doAuthCall;
