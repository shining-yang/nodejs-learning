//
// API - Get license log
//
var database = require('../lib/database');
var utility = require('../lib/utility');
var ecode = require('../lib/error-code');
var sqlScript = require('../lib/sql-statements');
var diagMod = require('../lib/log');


// Build the log item (including billing-time for `deduct` logs)
function buildLogItem(timeZone, billingCycle, logData) {
  if (logData.billing_id == 0) { // 0 for none-deduct log items, and we won't take with `billing-time`
    return {
      change_points: logData.change_point,
      action: logData.action,
      time_zone: timeZone,
      update_time: logData.last_update.formatAsUTC('yyyy-MM-dd hh:mm:ss')
    };
  } else {
    var billingTime = '';
    switch (billingCycle) {
      case 'day':
        billingTime = logData.start_time.format('yyyyMMdd');
        break;
      case 'month':
        billingTime = logData.start_time.format('yyyyMM');
        break;
      case 'week': // NOT SUPPORT currently
        break;
    }

    return {
      change_points: logData.change_point,
      action: logData.action,
      time_zone: timeZone,
      billing_time: billingTime,
      update_time: logData.last_update.formatAsUTC('yyyy-MM-dd hh:mm:ss')
    };
  }
}

// generate response on single license
function buildSuccessResponseSingle(timeZone, billingCycle, logs, pretty) {
  var resJson = {
    license_id: logs[0].license_id,
    remaining_points: logs[0].remaining_point,
    logs: []
  };

  for (var i = 0; i < logs.length; i++) {
    resJson.logs.push(buildLogItem(timeZone, billingCycle, logs[i]));
  }

  return utility.stringifyJsonObj(resJson, pretty);
}

// append a license-log to JSON for response
function appendLicenseLogToResponseJson(json, timeZone, billingCycle, log) {
  var count = json.licenses.length;
  if ((count == 0) || (json.licenses[count - 1].id != log.license_id)) {
    var licenseLogJson = {
      id: log.license_id,
      remaining_points: log.remaining_point,
      logs: []
    };
    licenseLogJson.logs.push(buildLogItem(timeZone, billingCycle, log));
    json.licenses.push(licenseLogJson);
  } else {
    json.licenses[count - 1].logs.push(buildLogItem(timeZone, billingCycle, log));
  }
}

// generate response on multiple licenses
function buildSuccessResponseMultiple(timeZone, billingCycle, logs, pretty) {
  var resJson = {
    licenses: []
  };

  for (var i = 0; i < logs.length; i++) {
    appendLicenseLogToResponseJson(resJson, timeZone, billingCycle, logs[i]);
  }

  return utility.stringifyJsonObj(resJson, pretty);
}

// retrieve license logs of specified license
function getLicenseLogSingle(req, sql, callback) {
  var script = sqlScript.getLicenseLogByOrgAndLic(req.params.orgIdInt, req.params.licId);
  diagMod.debugLog('license-log', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Get License Log', req.query.pretty));
    } else if (rows.length <= 0) {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponseOnLicenses('406-05', [req.params.licId], req.query.pretty));
    } else {
      callback(ecode.code.SUCCEED, buildSuccessResponseSingle(req.params.timeZone, req.params.billingCycle, rows, req.query.pretty));
    }

    sql.release();
  });
}

// retrieve all license logs within the specified organization
function getLicenseLogMultiple(req, sql, callback) {
  var script = sqlScript.getLicenseLogByOrg(req.params.orgIdInt);
  diagMod.debugLog('license-log', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Get License Log', req.query.pretty));
    } else {
      callback(ecode.code.SUCCEED, buildSuccessResponseMultiple(req.params.timeZone, req.params.billingCycle, rows, req.query.pretty));
    }

    sql.release();
  });
}

// access database to retrieve license logs
function perform(switchFunc, req, sql, callback) {
  // 1. check organization state
  var script = sqlScript.getOrganizationStateTimezoneBillingCycle(req.params.orgId);
  diagMod.debugLog('license-log', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Get License Log', req.query.pretty));
      sql.release();
    } else if (rows.length <= 0) {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-02', req.query.pretty));
      sql.release();
    } else if (rows[0].state == 'deducting') {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-10', req.query.pretty));
      sql.release();
    } else if (rows[0].state != 'normal' && rows[0].state != 'exhausted') {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-13', req.query.pretty));
      sql.release();
    } else {
      req.params.orgIdInt = rows[0].id; // save organization id <internal int value>
      req.params.timeZone = rows[0].time_zone;
      req.params.billingCycle = rows[0].cycle;
      switchFunc(req, sql, callback);
    }
  }); // check organization state
}

// switch implementation to support single/multiple logs
function implementSwitch(req, switchFunc, callback) {
  database.pool.getConnection(function (err, sql) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Get License Log', req.query.pretty));
    } else {
      perform(switchFunc, req, sql, callback);
    }
  });
}

// API implementation
function implement(req, res, switchFunc) {
  var startTime = new Date().getTime();
  var apiLog = {
    requestUrl: req.originalUrl,
    requestMethod: req.method,
    appId: req.user,
    requestIp: req.hostname,
    authorized: 1,
    error: 200,
    rtime: 0,
    requestParams: '',
    responseParams: ''
  };

  if (req.body.requests !== undefined) {
    apiLog.requestParams = JSON.stringify(req.body);
  }

  res.set('Content-Type', 'application/json');
  implementSwitch(req, switchFunc, function (errStatus, resText) {
    res.status(errStatus).end(resText);
    apiLog.rtime = new Date().getTime() - startTime;
    apiLog.error = errStatus;
    apiLog.responseParams = resText;
    utility.recordApiLog(apiLog);
  });
}

// API - get single license change log
function apiGetLicenseLogSingle(req, res) {
  implement(req, res, getLicenseLogSingle);
}

// API - get all license logs within specified organization-id
function apiGetLicenseLog(req, res) {
  implement(req, res, getLicenseLogMultiple);
}

module.exports.apiGetLicenseLogSingle = apiGetLicenseLogSingle;
module.exports.apiGetLicenseLog = apiGetLicenseLog;
