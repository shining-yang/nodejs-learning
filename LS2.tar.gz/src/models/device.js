/**
 * Created by root on 15-1-23.
 */
var database = require('../lib/database');
var ecode = require('../lib/error-code');
var utility = require('../lib/utility');
var sqlScript = require('../lib/sql-statements');
var diagMod = require('../lib/log');

function checkRequestFormat(requests) {
  for (var i = 0; i < requests.length; i++) {
    if (!requests[i].uid
      || requests[i].uid.constructor != String
      || requests[i].uid.length <= 0) {
      return false;
    }
  }

  return true;
}

function arrayContains(arr, item) {
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] === item) {
      return true;
    }
  }

  return false;
}

// Get duplicated license ids
function getDuplicateDevIds(requests) {
  var idsExisted = [];
  var idsDuplicate = [];
  for (var i = 0; i < requests.length; i++) {
    if (!arrayContains(idsExisted, requests[i].uid)) {
      idsExisted.push(requests[i].uid);
    } else {
      if (!arrayContains(idsDuplicate, requests[i].uid)) {
        idsDuplicate.push(requests[i].uid);
      }
    }
  }
  return idsDuplicate;
}

function deviceCheckJOSN(req, callback) {
  if (req.user === ecode.code.UNAUTHORIZED) {
    callback(1, "false", "401-01", "", req.params.orgId);
    return false;
  }

  // check the API syntax
  if (req.body == undefined
    || req.body.requests == undefined
    || !utility.checkContentTypeJson(req.headers['content-type'])
    || !Array.isArray(req.body.requests)
    || !checkRequestFormat(req.body.requests)) {
    callback(1, "false", "400-01", "", req.params.orgId);
    return false;
  }

  // check if there are some duplicated requests
  var dupIds = getDuplicateDevIds(req.body.requests);
  var i;
  var regArray = [];
  if (dupIds.length > 0) {
    for (i = 0; i < dupIds.length; i++) {
      regArray.push({
        'regModelId': 0,
        'regCode': "409-04",
        'regUnregTime': "0",
        'regUID': dupIds[i]
      });
    }
    callback("registerDevice", ecode.code.CONFLICT, "409-04", "", regArray);
    return false;
  }
  return true;
}

function registerDevice(req, callback) {
  diagMod.debugLog('register-device', 'Register device');

  /*
   if (req.user === ecode.code.UNAUTHORIZED) {
   callback(1, "false", "401-01", "", req.params.orgId)
   return;
   }
   */
  if (req.body == undefined
    || req.body.requests == undefined
    || !utility.checkContentTypeJson(req.headers['content-type'])
    || !Array.isArray(req.body.requests)
    || !checkRequestFormat(req.body.requests)) {
    callback(1, "false", "400-01", "", req.params.orgId);
    return;
  }

  var dupIds = getDuplicateDevIds(req.body.requests);
  var i;
  var uidArray = [];
  if (dupIds.length > 0) {
    for (i = 0; i < dupIds.length; i++) {
      uidArray.push({
        'regModelId': 0,
        'regCode': "409-04",
        'regUnregTime': "0",
        'regUID': dupIds[i]
      });
    }
    callback("registerDevice", ecode.code.CONFLICT, "409-04", "", uidArray);
    return;
  }

  database.pool.getConnection(function (err, connection) {
    if (err) {
      diagMod.errorLog('register-device', 'the sql connect error');
      callback("false", ecode.code.METHOD_FAILURE, "420-02", "Register Device", req.params.orgId);
      return;
    }
    var organizationID;
    var orgState;
    var orgTimeZone;
    var orgLen;
    var orgZone;
    var expensePerUnit;
    var strUids;
    var strSql;
    var checkCount;
    var reslength;
    var orgRemainingPoint;
    var organizationName = req.params.orgId;
    var script;
    script = sqlScript.deviceGetOrgInfo(req.params.orgId);
    diagMod.debugLog('register-device', 'SQL:' + script);
    connection.query(script, function (err, result) {
      if (err) {
        diagMod.errorLog('register-device', 'the sql connect error');
        connection.release();
        callback(1, ecode.code.METHOD_FAILURE, "420-01", "Register Device", req.params.orgId);
        return;
      }
      orgLen = result.length;
      if (orgLen <= 0) {
        diagMod.debugLog('register-device', 'the organization is not existed');
        connection.release();
        callback(1, ecode.code.NOT_ACCEPTABLE, "406-02", "", req.params.orgId);
        return;
      }
      organizationID = result[0].id;
      orgState = result[0].state;
      orgTimeZone = result[0].time_zone;
      orgZone = result[0].zone;
      if (orgState == 'deducting') {
        diagMod.debugLog('register-device', 'the organization is deducting');
        connection.release();
        callback(1, ecode.code.NOT_ACCEPTABLE, "406-10", "", req.params.orgId);
        return;
      }
      if (orgState != 'normal') {
        diagMod.debugLog('register-device', 'the organization is not exhausted');
        connection.release();
        callback(1, ecode.code.NOT_ACCEPTABLE, "406-11", "", organizationName);
        return;
      }
      script = sqlScript.deviceGetDevBudget(organizationID);
      diagMod.debugLog('register-device', 'SQL:' + script);
      connection.query(script, function (err, result) {
        if (err) {
          diagMod.errorLog('register-device', 'the sql execute error');
          connection.release();
          callback(1, ecode.code.METHOD_FAILURE, "420-01", "Register Device", req.params.orgId);
          return;
        }
        expensePerUnit = result[0][0].budget_points;
        var jsonData = req.body.requests;
        var isPerform = req.body.is_perform;
        strUids = "";

        var regArray = [];
        for (var i = 0; i < jsonData.length; i++) {
          regArray.push({
            'regModelId': 0,
            'regCode': "406-04",
            'regUnregTime': "0",
            'regUID': jsonData[i].uid
          });
          strUids += "'";
          strUids += jsonData[i].uid;
          strUids += "'";
          if (i != (jsonData.length - 1)) {
            strUids += ',';
          }
        }
        diagMod.debugLog('register-device', strUids);
        script = sqlScript.deviceGetDevModelId(strUids);
        diagMod.debugLog('register-device', 'SQL:' + script);
        //var strSqlParams = [strUids, strUids];
        //    connection.query('select device_model_id, id  from device_uid where id IN (?) ORDER BY FIELD(id,?)', [strUids, strUids], function(err,result) {
        connection.query(script, function (err, result) {
          if (err) {
            diagMod.errorLog('register-device', 'the sql execute error');
            connection.release();
            callback(1, ecode.code.METHOD_FAILURE, "420-01", "Register Device", req.params.orgId);
            return;
          }
          checkCount = jsonData.length;
          reslength = result.length;
          var j = 0;
          var i = 0;
          for (i = 0; i < jsonData.length; i++) {
            if (result.length > j) {
              if (regArray[i].regUID == result[j].id) {
                regArray[i].regCode = "200";
                regArray[i].regModelId = result[j].device_model_id;
                j++;
              }
            }
          }
          if (j == i) {
            script = sqlScript.deviceGetRegDevId(strUids);
            diagMod.debugLog('register-device', 'SQL:' + script);
            connection.query(script, function (err, result) {
              if (err) {
                diagMod.errorLog('register-device', 'the sql execute error');
                connection.release();
                callback(1, ecode.code.METHOD_FAILURE, "420-01", "Register Device", req.params.orgId);
                return;
              }
              var j = 0;
              var i = 0;
              for (i = 0; i < jsonData.length; i++) {
                if (result.length > j) {
                  if (regArray[i].regUID == result[j].device_id) {
                    regArray[i].regCode = "409-02";
                    j++;
                  }
                }
              }
              if (j == 0) {
                script = sqlScript.deviceGetCycle(organizationID);
                diagMod.debugLog('register-device', 'SQL:' + script);
                connection.query(script, function (err, result) {
                  if (err) {
                    diagMod.errorLog('register-device', 'the sql execute error');
                    connection.release();
                    callback(1, ecode.code.METHOD_FAILURE, "420-01", "Register Device", req.params.orgId);
                    return;
                  }
                  if (result.length > 0) {
                    var billingProfileID = result[0].id;
                    var billingProfileCycle = result[0].cycle;
                    script = sqlScript.deviceGetRegDevExpense(billingProfileID, strUids);
                    diagMod.debugLog('register-device', 'SQL:' + script);
                    connection.query(script, function (err, result) {
                      if (err) {
                        diagMod.errorLog('register-device', 'the sql execute error');
                        connection.release();
                        callback(1, ecode.code.METHOD_FAILURE, "420-01", "Register Device", req.params.orgId);
                        return;
                      }
                      var points = result[0].expense;
                      points += expensePerUnit;
                      script = sqlScript.deviceGetOrgTotalPoints(organizationID);
                      diagMod.debugLog('register-device', 'SQL:' + script);
                      connection.query(script, function (err, result) {
                        if (err) {
                          diagMod.errorLog('register-device', 'the sql execute error');
                          connection.release();
                          callback(1, ecode.code.METHOD_FAILURE, "420-01", "Register Device", req.params.orgId);
                          return;
                        }
                        orgRemainingPoint = result[0].remainingPoint;
                        if (points <= orgRemainingPoint) {
                          var orgExpiration = '';
                          if (points != 0 && orgRemainingPoint != 0) {
                            if ((orgState == 'normal') && (orgRemainingPoint < points)) {
                              orgExpiration = 1;
                            }
                            else {
                              orgExpiration = parseInt(orgRemainingPoint / points);
                            }
                          }
                          var resJson = {
                            "organization": {
                              "points": orgRemainingPoint,
                              "expense_per_unit": points,
                              "unit": billingProfileCycle,
                              "expiration": orgExpiration
                            }
                          };
                          if (isPerform) {
                            script = sqlScript.deviceGetUpdateUnregTime(organizationID, orgTimeZone, strUids);
                            diagMod.debugLog('register-device', 'SQL:' + script);
                            connection.query(script, function (err, result) {
                              if (err) {
                                diagMod.errorLog('register-device', 'the sql execute error');
                                connection.release();
                                callback(1, ecode.code.METHOD_FAILURE, "420-01", "Register Device", req.params.orgId);
                                return;
                              }
                              var j = 0;
                              var i = 0;
                              var strUpdateUids = '';
                              var strInsertUids = '';
                              var strInsertUidsLog = '';
                              //  if(result.length == 0) {
                              strUpdateUids += '"NULL",';
                              //   }
                              for (i = 0; i < jsonData.length; i++) {
                                if (result.length > j) {
                                  if (regArray[i].regUID == result[j].id) {
                                    if (result[j].time != 0) {
                                      regArray[i].regUnregTime = result[j].time;
                                      strUpdateUids += "'";
                                      strUpdateUids += result[j].time;
                                      strUpdateUids += "'";
                                      strUpdateUids += ',';
                                      strInsertUidsLog += '("' + regArray[i].regUID + '",' + organizationID + ', "register", NOW()),'
                                    }
                                    j++;
                                  }
                                }
                              }
                              for (i = 0; i < jsonData.length; i++) {
                                if (regArray[i].regUnregTime == '0') {
                                  strInsertUids += '("' + regArray[i].regUID + '",' + organizationID + ', NOW(), 0),'
                                  strInsertUidsLog += '("' + regArray[i].regUID + '",' + organizationID + ', "register", NOW()),'
                                }
                              }
                              strUpdateUids = strUpdateUids.substring(0, strUpdateUids.length - 1);
                              if (strInsertUids.length > 1) {
                                strInsertUids = strInsertUids.substring(0, strInsertUids.length - 1);
                              }
                              if (strInsertUidsLog.length > 1) {
                                strInsertUidsLog = strInsertUidsLog.substring(0, strInsertUidsLog.length - 1);
                              }
                              connection.beginTransaction(function (err) {
                                if (err) {
                                  diagMod.errorLog('register-device', 'the sql beginTransaction error');
                                  connection.release();
                                  callback(1, ecode.code.METHOD_FAILURE, "420-01", "Register Device", organizationName);
                                  return;
                                }
                                script = sqlScript.deviceUpdateUnregTime(organizationID, strUpdateUids);
                                diagMod.debugLog('register-device', 'SQL:' + script);
                                connection.query(script, function (err, result) {
                                  if (err) {
                                    connection.rollback(function () {
                                      diagMod.errorLog('register-device', 'update device error');
                                      connection.release();
                                      callback(1, ecode.code.METHOD_FAILURE, "420-01", "Register Device", organizationName);
                                    });
                                    return;
                                  }
                                  if (strInsertUids != '') {
                                    script = sqlScript.deviceInsertRegisterdev(strInsertUids);
                                  }
                                  else {
                                    script = 'select count(id) from device';
                                  }
                                  diagMod.debugLog('register-device', 'SQL:' + script);
                                  connection.query(script, function (err, result) {
                                    if (err) {
                                      connection.rollback(function () {
                                        diagMod.errorLog('register-device', 'insert into device error');
                                        connection.release();
                                        callback(1, ecode.code.METHOD_FAILURE, "420-01", "Register Device", organizationName);
                                      });
                                      return;
                                    }
                                    script = sqlScript.deviceInsertRegisterdevLog(strInsertUidsLog);
                                    diagMod.debugLog('register-device', 'SQL:' + script);
                                    connection.query(script, function (err, result) {
                                      if (err) {
                                        connection.rollback(function () {
                                          diagMod.errorLog('register-device', 'insert into device_log error');
                                          connection.release();
                                          callback(1, ecode.code.METHOD_FAILURE, "420-01", "Register Device", organizationName);
                                        });
                                        return;
                                      }
                                      connection.commit(function (err) {
                                        if (err) {
                                          connection.rollback(function () {
                                            diagMod.errorLog('register-device', 'register device commit error');
                                            connection.release();
                                            callback(1, ecode.code.METHOD_FAILURE, "420-01", "Register Device", organizationName);
                                          });
                                          return;
                                        }
                                        diagMod.debugLog('register-device', 'register device success');
                                        connection.release();
                                        callback("registerDevice", "true", "201", "", resJson);
                                      });
                                    });
                                  });
                                })
                              })
                            })
                          }
                          else {
                            diagMod.debugLog('register-device', 'register device success');
                            connection.release();
                            callback("registerDevice", "true", "201", "", resJson);
                          }
                        }
                        else {
                          connection.release();
                          callback(1, ecode.code.NOT_ACCEPTABLE, "406-08", "", organizationName);
                        }
                      })
                    })
                  }
                })
              }
              else {
                connection.release();
                callback("registerDevice", ecode.code.CONFLICT, "409-02", "", regArray);
              }
            })
          }
          else {
            connection.release();
            callback("registerDevice", ecode.code.NOT_ACCEPTABLE, "406-04", "", regArray);
          }
        })
      })
    })
  })
}

function unRegisterDevice(req, callback) {
  diagMod.debugLog('unregister-device', 'Unregister Device');

  if (req.body == undefined
    || req.body.requests == undefined
    || !utility.checkContentTypeJson(req.headers['content-type'])
    || !Array.isArray(req.body.requests)
    || !checkRequestFormat(req.body.requests)) {
    callback(1, "false", "400-01", "", req.params.orgId);
    return;
  }

  var dupIds = getDuplicateDevIds(req.body.requests);
  var i;
  var uidArray = [];
  if (dupIds.length > 0) {
    for (i = 0; i < dupIds.length; i++) {
      uidArray.push({
        'regModelId': 0,
        'regCode': "409-04",
        'regUnregTime': "0",
        'regUID': dupIds[i]
      });
    }
    callback("registerDevice", ecode.code.CONFLICT, "409-04", "", uidArray);
    return;
  }

  database.pool.getConnection(function (err, connection) {
    if (err) {
      diagMod.errorLog('unregister-device', 'the sql connect error');
      callback("false", ecode.code.METHOD_FAILURE, "420-02", "Unregister Device", req.params.orgId);
      return;
    }
    var organizationID;
    var orgState;
    var orgTimeZone;
    var orgLen;
    var orgZone;
    var expensePerUnit;
    var strUids;
    var strSql;
    var checkCount;
    var reslength;
    var orgRemainingPoint;
    var organizationName = req.params.orgId;
    var script;
    var code;
    var onOff = true;
    script = sqlScript.deviceGetOrgInfo(req.params.orgId);
    diagMod.debugLog('unregister-device', 'SQL:' + script);
    connection.query(script, function (err, result) {
      if (err) {
        diagMod.errorLog('unregister-device', 'the sql execute error');
        connection.release();
        callback(1, ecode.code.METHOD_FAILURE, "420-01", "Unregister Device", req.params.orgId);
        return;
      }
      orgLen = result.length;
      if (orgLen <= 0) {
        diagMod.debugLog('unregister-device', 'the organization is not existed');
        connection.release();
        callback(1, ecode.code.NOT_ACCEPTABLE, "406-02", "", req.params.orgId);
        return;
      }
      organizationID = result[0].id;
      orgState = result[0].state;
      orgTimeZone = result[0].time_zone;
      orgZone = result[0].zone;
      if (orgState == 'deducting') {
        diagMod.debugLog('unregister-device', 'the organization is deducting');
        connection.release();
        callback(1, ecode.code.NOT_ACCEPTABLE, "406-10", "", req.params.orgId);
        return;
      }
      if (orgState == 'removed') {
        diagMod.debugLog('unregister-device', 'The organization is not in normal mode or exhausted mode');
        connection.release();
        callback(1, ecode.code.NOT_ACCEPTABLE, "406-13", "", organizationName);
        return;
      }
      var jsonData = req.body.requests;
      var isPerform = req.body.is_perform;
      strUids = "";

      var regArray = [];
      for (var i = 0; i < jsonData.length; i++) {
        regArray.push({
          'regModelId': 0,
          'regCode': "406-04",
          'regUnregTime': "0",
          'regUID': jsonData[i].uid
        });
        strUids += "'";
        strUids += jsonData[i].uid;
        strUids += "'";
        if (i != (jsonData.length - 1)) {
          strUids += ',';
        }
      }
      diagMod.debugLog('unregister-device', strUids);
      script = sqlScript.deviceGetDevModelId(strUids);
      diagMod.debugLog('unregister-device', 'SQL:' + script);
      //var strSqlParams = [strUids, strUids];
      //    connection.query('select device_model_id, id  from device_uid where id IN (?) ORDER BY FIELD(id,?)', [strUids, strUids], function(err,result) {
      connection.query(script, function (err, result) {
        if (err) {
          diagMod.errorLog('unregister-device', 'the sql execute error');
          connection.release();
          callback(1, ecode.code.METHOD_FAILURE, "420-01", "Unregister Device", req.params.orgId);
          return;
        }
        checkCount = jsonData.length;
        reslength = result.length;
        var j = 0;
        var i = 0;
        for (i = 0; i < jsonData.length; i++) {
          if (result.length > j) {
            if (regArray[i].regUID == result[j].id) {
              regArray[i].regCode = "200";
              regArray[i].regModelId = result[j].device_model_id;
              j++;
            }
          }
        }
        if (j == i) {
          script = sqlScript.deviceGetRegDevId(strUids);
          diagMod.debugLog('unregister-device', 'SQL:' + script);
          connection.query(script, function (err, result) {
            if (err) {
              diagMod.errorLog('unregister-device', 'the sql execute error');
              connection.release();
              callback(1, ecode.code.METHOD_FAILURE, "420-01", "Unregister Device", req.params.orgId);
              return;
            }
            var j = 0;
            var i = 0;
            for (i = 0; i < jsonData.length; i++) {
              if (result.length > 0) {
                if (regArray[i].regUID != result[j].device_id) {
                  regArray[i].regCode = "406-09";
                  onOff = false;
                }
                else {
                  if (result.length > (j + 1)) {
                    j++;
                  }
                }
              }
              else {
                regArray[i].regCode = "406-09";
                onOff = false;
              }
            }
            if (onOff) {
              script = sqlScript.deviceGetOrgTotalPoints(organizationID);
              diagMod.debugLog('unregister-device', 'SQL:' + script);
              connection.query(script, function (err, result) {
                if (err) {
                  diagMod.errorLog('unregister-device', 'the sql execute error');
                  connection.release();
                  callback(1, ecode.code.METHOD_FAILURE, "420-01", "Unregister Device", req.params.orgId);
                  return;
                }
                orgRemainingPoint = result[0].remainingPoint;
                var j = 0;
                var i = 0;
                var strUpdateUids = '';
                var strInsertUidsLog = '';
                strUpdateUids += '"NULL",';

                for (i = 0; i < jsonData.length; i++) {
                  if (regArray[i].regCode == '200') {
                    strInsertUidsLog += '("' + regArray[i].regUID + '",' + organizationID + ', "unregister", NOW()),';
                    strUpdateUids += "'";
                    strUpdateUids += regArray[i].regUID;
                    strUpdateUids += "'";
                    strUpdateUids += ',';
                  }
                }
                strUpdateUids = strUpdateUids.substring(0, strUpdateUids.length - 1);
                if (strInsertUidsLog.length > 1) {
                  strInsertUidsLog = strInsertUidsLog.substring(0, strInsertUidsLog.length - 1);
                }
                connection.beginTransaction(function (err) {
                  if (err) {
                    diagMod.errorLog('unregister-device', 'the sql beginTransaction error');
                    connection.release();
                    callback(1, ecode.code.METHOD_FAILURE, "420-01", "Unregister Device", organizationName);
                    return;
                  }
                  script = sqlScript.deviceUpdateUnregTimeNow(organizationID, strUpdateUids);
                  diagMod.debugLog('unregister-device', 'SQL:' + script);
                  connection.query(script, function (err, result) {
                    if (err) {
                      connection.rollback(function () {
                        diagMod.errorLog('unregister-device', 'update device error');
                        connection.release();
                        callback(1, ecode.code.METHOD_FAILURE, "420-01", "Unregister Device", organizationName);
                      });
                      return;
                    }
                    script = sqlScript.deviceInsertRegisterdevLog(strInsertUidsLog);
                    diagMod.debugLog('unregister-device', 'SQL:' + script);
                    connection.query(script, function (err, result) {
                      if (err) {
                        connection.rollback(function () {
                          diagMod.errorLog('unregister-device', 'insert into device_log error');
                          connection.release();
                          callback(1, ecode.code.METHOD_FAILURE, "420-01", "Unregister Device", organizationName);
                        });
                        return;
                      }
                      connection.commit(function (err) {
                        if (err) {
                          connection.rollback(function () {
                            diagMod.errorLog('unregister-device', 'Unregister Device commit error');
                            connection.release();
                            callback(1, ecode.code.METHOD_FAILURE, "420-01", "Unregister Device", organizationName);
                          });
                          return;
                        }
                        diagMod.debugLog('unregister-device', 'Unregister Device success');
                        script = sqlScript.deviceGetDevBudget(organizationID);
                        diagMod.debugLog('unregister-device', 'SQL:' + script);
                        connection.query(script, function (err, result) {
                          if (err) {
                            diagMod.errorLog('unregister-device', 'the sql execute error');
                            connection.release();
                            callback(1, ecode.code.METHOD_FAILURE, "420-01", "Unregister Device", req.params.orgId);
                            return;
                          }
                          expensePerUnit = result[0][0].budget_points;
                          var orgExpiration = '';
                          if (expensePerUnit != 0 && orgRemainingPoint != 0) {
                            if ((orgState == 'normal') && (orgRemainingPoint < expensePerUnit)) {
                              orgExpiration = 1;
                            }
                            else {
                              orgExpiration = parseInt(orgRemainingPoint / expensePerUnit);
                            }
                          }
                          script = sqlScript.deviceGetCycle(organizationID);
                          diagMod.debugLog('unregister-device', 'SQL:' + script);
                          connection.query(script, function (err, result) {
                            if (err) {
                              diagMod.errorLog('unregister-device', 'the sql execute error');
                              connection.release();
                              callback(1, ecode.code.METHOD_FAILURE, "420-01", "Unregister Device", req.params.orgId);
                              return;
                            }
                            if (result.length > 0) {
                              var billingProfileID = result[0].id;
                              var billingProfileCycle = result[0].cycle;
                            }
                            var resJson = {
                              "organization": {
                                "points": orgRemainingPoint,
                                "expense_per_unit": expensePerUnit,
                                "unit": billingProfileCycle,
                                "expiration": orgExpiration
                              }
                            };
                            connection.release();
                            callback("unRegisterDevice", "true", "200", "", resJson);
                            diagMod.debugLog('unregister-device', 'Unregister device success');
                          });
                        });
                      });
                    });
                  })
                })
              })
            }
            else {
              connection.release();
              callback("unRegisterDevice", ecode.code.NOT_ACCEPTABLE, "406-09", "", regArray);
            }
          })
        }
        else {
          connection.release();
          callback("unRegisterDevice", ecode.code.NOT_ACCEPTABLE, "406-04", "", regArray);
        }
      })
    })
  })
}

function isTime(str) {
  if (str.length == 6) {
    var a = str.match(/^(\d{1,4})(\d{1,2})$/);
    if (a == null) {
      return false;
    }
    if (a[2] > 12) {
      return false;
    }
  }
  else if (str.length == 8) {
    var strTime = str.match(/^(\d{1,4})(\d{1,2})(\d{1,2})$/);
    if (strTime == null) {
      return false;
    }
    if (strTime[2] > 12) {
      return false;
    }
    var day = new Date(strTime[1], strTime[2], 0);
    var daycount = day.getDate();
    if (daycount < strTime[3]) {
      return false;
    }
  }
  else {
    return false;
  }
  return true;
}

function getDevicesLog(req, callback) {
  diagMod.debugLog('get-devices-log', 'Get devices log');
  database.pool.getConnection(function (err, connection) {
    if (err) {
      diagMod.errorLog('get-devices-log', 'the sql connect error');
      callback("false", ecode.code.METHOD_FAILURE, "420-02", "Get devices log", req.params.orgId);
      return;
    }
    var organizationID;
    var orgState;
    var orgTimeZone;
    var orgLen;
    var orgZone;
    var strUids;
    var strSql;
    var checkCount;
    var reslength;
    var orgRemainingPoint;
    var organizationName = req.params.orgId;
    var logDate = req.params.date;
    var resJson = {};
    var script;
    if (!isTime(logDate)) {
      diagMod.errorLog('get-devices-log', 'date error');
      connection.release();
      callback("false", ecode.code.BAD_REQUEST, "400-01", "Get devices log", organizationName);
      return;
    }
    script = sqlScript.deviceGetOrgInfo(req.params.orgId);
    diagMod.debugLog('get-devices-log', 'SQL:' + script);
    connection.query(script, function (err, result) {
      if (err) {
        diagMod.errorLog('get-devices-log', 'the sql execute error');
        connection.release();
        callback(1, ecode.code.METHOD_FAILURE, "420-01", "Get devices log", req.params.orgId);
        return;
      }
      orgLen = result.length;
      if (orgLen <= 0) {
        diagMod.debugLog('get-devices-log', 'the organization is not existed');
        connection.release();
        callback(1, ecode.code.NOT_ACCEPTABLE, "406-02", "", req.params.orgId);
        return;
      }
      organizationID = result[0].id;
      orgState = result[0].state;
      orgTimeZone = result[0].time_zone;
      orgZone = result[0].zone;
      if (orgState == 'deducting') {
        diagMod.debugLog('get-devices-log', 'the organization is deducting');
        connection.release();
        callback(1, ecode.code.NOT_ACCEPTABLE, "406-10", "", req.params.orgId);
        return;
      }
      if (!(orgState == 'normal' || orgState == 'exhausted')) {
        diagMod.debugLog('get-devices-log', 'the organization is not exhausted');
        connection.release();
        callback(1, ecode.code.NOT_ACCEPTABLE, "406-13", "", organizationName);
        return;
      }
      script = sqlScript.deviceGetCycle(organizationID);
      diagMod.debugLog('get-devices-log', 'SQL:' + script);
      connection.query(script, function (err, result) {
        if (err) {
          diagMod.errorLog('get-devices-log', 'the sql execute error');
          connection.release();
          callback(1, ecode.code.METHOD_FAILURE, "420-01", "Unregister Device", req.params.orgId);
          return;
        }
        if (result[0].cycle == 'month' && logDate.length != 6) {
          diagMod.errorLog('get-devices-log', 'date error');
          connection.release();
          callback(1, ecode.code.BAD_REQUEST, "400-01", "GetDevicesLog", organizationName);
          return;
        }
        if (result[0].cycle == 'day' && logDate.length != 8) {
          diagMod.errorLog('get-devices-log', 'date error');
          connection.release();
          callback("false", ecode.code.BAD_REQUEST, "400-01", "GetDevicesLog", organizationName);
          return;
        }
        script = sqlScript.deviceGetDevLogInfo(organizationID, logDate);
        diagMod.debugLog('get-devices-log', 'SQL:' + script);
        connection.query(script, function (err, result) {
          if (err) {
            diagMod.errorLog('get-devices-log', 'the sql execute error');
            connection.release();
            callback(1, ecode.code.METHOD_FAILURE, "420-01", "Get devices log", req.params.orgId);
            return;
          }
          var uniqueDevices = 0;
          resJson.unique_devices = 0;
          resJson.device_time = [];
          for (var i = 0; i < result.length; i++) {
            uniqueDevices += result[i].count;
            resJson.device_time.push({
              "model": result[0].mod_id,
              "unit": result[0].time_unit,
              "total": result[0].total_time
            });
          }
          resJson.unique_devices = uniqueDevices;
          connection.release();
          callback("getDevicesLog", "true", "200", "", resJson);
          diagMod.debugLog('get-devices-log', 'Get devices log success');
        })
      })
    })
  })
}

module.exports.registerDevice = registerDevice;
module.exports.unRegisterDevice = unRegisterDevice;
module.exports.getDevicesLog = getDevicesLog;
