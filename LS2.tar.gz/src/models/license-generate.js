//
// API - import licenses to license-repository
//
var database = require('../lib/database');
var utility = require('../lib/utility');
var ecode = require('../lib/error-code');
var sqlScript = require('../lib/sql-statements');
var diagMod = require('../lib/log');

// ensure that the requested data format is correct
function checkRequestFormat(requests) {
  for (var i = 0; i < requests.length; i++) {
    if (requests[i].license_key == undefined
      || requests[i].license_key.constructor != String
      || requests[i].license_key.length != 20) { // license-id is fixed 20-chars
      return false;
    }

    if (requests[i].points == undefined
      || requests[i].points.constructor != Number) {
      return false;
    }

    if (requests[i].pk_number == undefined
      || requests[i].pk_number.constructor != String
      || requests[i].pk_number.length <= 0) {
      return false;
    }

    if (requests[i].model_name == undefined
      || requests[i].model_name.constructor != String
      || requests[i].model_name.length <= 0) {
      return false;
    }
  }

  return true;
}

// Determine if an array contains the specified element
function arrayContains(arr, item) {
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] === item) {
      return true;
    }
  }

  return false;
}

// Get duplicated license ids
function getDuplicateLicenseIds(requests) {
  var idsExisted = [];
  var idsDuplicate = [];
  for (var i = 0; i < requests.length; i++) {
    if (!arrayContains(idsExisted, requests[i].license_key)) { // NOTE: `license_key` here
      idsExisted.push(requests[i].license_key);
    } else {
      if (!arrayContains(idsDuplicate, requests[i].license_key)) {
        idsDuplicate.push(requests[i].license_key);
      }
    }
  }

  return idsDuplicate;
}

// filter the existed IDs
function captureExistedIds(results) {
  var ids = [];
  for (var i = 0; i < results.length; i++) {
    ids.push(results[i].license_id);
  }

  return ids;
}

// implement the API
function importLicenseToRepository(req, callback) {
  // SPECIAL API, only allowed for DHQ
  if (req.user !== 'DHQ') {
    callback(ecode.code.FORBIDDEN, ecode.errorResponse('403-01', req.query.pretty));
    return;
  }

  // check the API syntax
  if (req.body === undefined
    || req.body.requests === undefined
    || !utility.checkContentTypeJson(req.headers['content-type'])
    || !Array.isArray(req.body.requests)
    || !checkRequestFormat(req.body.requests)) {
    callback(ecode.code.BAD_REQUEST, ecode.errorResponse2('400-01', req.query.pretty));
    return;
  }

  // check if there are some duplicated requests
  var dupIds = getDuplicateLicenseIds(req.body.requests);
  if (dupIds.length > 0) {
    callback(ecode.code.CONFLICT, ecode.errorResponseOnLicenses2('409-04', dupIds, req.query.pretty));
    return;
  }

  // access database
  database.pool.getConnection(function (err, sql) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara2('420-01', 'Import License', req.query.pretty));
    } else {
      var script = sqlScript.getExistingLicenses(req.body.requests);
      diagMod.debugLog('import-license', 'SQL: ' + script);
      sql.query(script, function (err, rows) {
        if (err) {
          callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara2('420-01', 'Import License', req.query.pretty));
          sql.release();
        } else if (rows.length > 0) {
          var existedIds = captureExistedIds(rows);
          callback(ecode.code.CONFLICT, ecode.errorResponseOnLicenses2('409-03', existedIds, req.query.pretty));
          sql.release();
        } else {
          var script = sqlScript.insertImportLicenses(req.body.requests, req.params.obu);
          diagMod.debugLog('import-license', 'SQL: ' + script);
          sql.query(script, function (err, result) {
            if (err) {
              callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara2('420-01', 'Import License', req.query.pretty));
              sql.release();
            } else {
              diagMod.debugLog('import-license', 'Import licenses success.');
              callback(ecode.code.CREATED, utility.stringifyJsonObj({success: 'true'}));
              sql.release();
            }
          });
        }
      });
    }
  });
}

// API: import licenses to repository
function apiGenerateLicense(req, res) {
  var startTime = new Date().getTime();
  var apiLog = {
    requestUrl: req.originalUrl,
    requestMethod: req.method,
    appId: req.user,
    requestIp: req.hostname,
    authorized: 1,
    error: 200,
    rtime: 0,
    requestParams: '',
    responseParams: ''
  };

  if (req.body.requests !== undefined) {
    apiLog.requestParams = JSON.stringify(req.body);
  }

  res.set('Content-Type', 'application/json');
  importLicenseToRepository(req, function (errStatus, resText) {
    res.status(errStatus).end(resText);
    apiLog.rtime = new Date().getTime() - startTime;
    apiLog.error = errStatus;
    apiLog.responseParams = resText;
    utility.recordApiLog(apiLog);
  });
}

module.exports = apiGenerateLicense;
