//
// API - Get license info
//
var database = require('../lib/database');
var utility = require('../lib/utility');
var ecode = require('../lib/error-code');
var sqlScript = require('../lib/sql-statements');
var diagMod = require('../lib/log');

// generate response on single license
function buildSuccessResponseSingle(cycle, orgName, license, pretty) {
  var resJson = {
    licenses: {
      id: license.id,
      original_points: license.original_point,
      remaining_points: license.remaining_point,
      unit: cycle,
      expiration: '', // use empty string to denote no due date
      belongs_to: orgName,
      deposited_by: license.user_id,
      activation_time: license.last_update.formatAsUTC('yyyy-MM-dd hh:mm:ss')
    }
  };

  return utility.stringifyJsonObj(resJson, pretty);
}

// generate response on multiple licenses
function buildSuccessResponseMultiple(cycle, orgName, licenses, pretty) {
  var resJson = {
    licenses: []
  };

  for (var i = 0; i < licenses.length; i++) {
    resJson.licenses.push({
      id: licenses[i].id,
      original_points: licenses[i].original_point,
      remaining_points: licenses[i].remaining_point,
      unit: cycle,
      expiration: '', // use empty string to denote no due date
      belongs_to: orgName,
      deposited_by: licenses[i].user_id,
      activation_time: licenses[i].last_update.formatAsUTC('yyyy-MM-dd hh:mm:ss')
    });
  }

  return utility.stringifyJsonObj(resJson, pretty);
}

// retrieve specified license info
function getLicenseInfoSingle(req, sql, cycle, callback) {
  var script = sqlScript.getLicenseInfoWithId(req.params.orgIdInt, req.params.licId);
  diagMod.debugLog('license-info', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Get License Info', req.query.pretty));
    } else if (rows.length != 1) {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponseOnLicenses('406-05', [req.params.licId], req.query.pretty));
    } else {
      callback(ecode.code.SUCCEED, buildSuccessResponseSingle(cycle, req.params.orgId, rows[0], req.query.pretty));
    }

    sql.release();
  });
}

// retrieve all license info within the specified organization
function getLicenseInfoMultiple(req, sql, cycle, callback) {
  var script = sqlScript.getLicenseInfo(req.params.orgIdInt);
  diagMod.debugLog('license-info', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Get License Info', req.query.pretty));
    } else {
      callback(ecode.code.SUCCEED, buildSuccessResponseMultiple(cycle, req.params.orgId, rows, req.query.pretty));
    }

    sql.release();
  });
}

// access database for license info
function perform(switchFunc, req, sql, callback) {
  // 1. check organization state
  var script = sqlScript.getOrganizationState(req.params.orgId);
  diagMod.debugLog('license-info', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Get License Info', req.query.pretty));
      sql.release();
    } else if (rows.length <= 0) {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-02', req.query.pretty));
      sql.release();
    } else if (rows[0].state == 'deducting') {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-10', req.query.pretty));
      sql.release();
    } else if (rows[0].state != 'normal' && rows[0].state != 'exhausted') {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-13', req.query.pretty));
      sql.release();
    } else {
      req.params.orgIdInt = rows[0].id; // save organization id <int>
      // 2. get billing cycle which used as `unit`
      var script = sqlScript.getBillingCycle(req.params.orgIdInt);
      diagMod.debugLog('license-info', 'SQL: ' + script);
      sql.query(script, function (err, rowsBillingCycle) {
        if (err || (rowsBillingCycle.length != 1)) {
          callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Get License Info', req.query.pretty));
          sql.release();
        } else {
          switchFunc(req, sql, rowsBillingCycle[0].cycle, callback);
        }
      }); // get billing cycle
    }
  }); // check organization state
}

// make a switch to implement single/multiple respectively
function implementSwitch(req, switchFunc, callback) {
  database.pool.getConnection(function (err, sql) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Get License Info', req.query.pretty));
    } else {
      perform(switchFunc, req, sql, callback);
    }
  });
}

// API implementation
function implement(req, res, switchFunc) {
  var startTime = new Date().getTime();
  var apiLog = {
    requestUrl: req.originalUrl,
    requestMethod: req.method,
    appId: req.user,
    requestIp: req.hostname,
    authorized: 1,
    error: 200,
    rtime: 0,
    requestParams: '',
    responseParams: ''
  };

  if (req.body.requests !== undefined) {
    apiLog.requestParams = JSON.stringify(req.body);
  }

  res.set('Content-Type', 'application/json');
  implementSwitch(req, switchFunc, function (errStatus, resText) {
    res.status(errStatus).end(resText);
    apiLog.rtime = new Date().getTime() - startTime;
    apiLog.error = errStatus;
    apiLog.responseParams = resText;
    utility.recordApiLog(apiLog);
  });
}

// API - get single license info
function apiGetLicenseInfoSingle(req, res) {
  implement(req, res, getLicenseInfoSingle);
}

// API - get all license info within specified organization-id
function apiGetLicenseInfo(req, res) {
  implement(req, res, getLicenseInfoMultiple);
}

module.exports.apiGetLicenseInfoSingle = apiGetLicenseInfoSingle;
module.exports.apiGetLicenseInfo = apiGetLicenseInfo;
