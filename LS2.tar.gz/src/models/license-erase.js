//
// API - erase license
//
var database = require('../lib/database');
var utility = require('../lib/utility');
var ecode = require('../lib/error-code');
var sqlScript = require('../lib/sql-statements');
var diagMod = require('../lib/log');

// commit changes on erasing license
function doCommitChanges(req, sql, callback) {
  sql.commit(function (err) {
    if (err) {
      sql.rollback(function () {
      });
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Erase License', req.query.pretty));
      sql.release();
    } else {
      diagMod.debugLog('erase-license', 'Erase license success.');
      callback(ecode.code.SUCCEED, ''); // empty on success
      sql.release();
    }
  });
}

// log after erase license
function doLogOnEraseLicense(req, sql, callback) {
  var script = sqlScript.insertEraseLicenseLog(req.params.orgIdInt, req.params.licId,
    req.params.licRemainingPoints);
  diagMod.debugLog('erase-license', 'SQL: ' + script);
  sql.query(script, function (err, result) {
    if (err) {
      sql.rollback(function () {
      });
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Erase License', req.query.pretty));
      sql.release();
    } else {
      doCommitChanges(req, sql, callback);
    }
  });
}

// remove a specific license entry
function doRemoveFromLicense(req, sql, callback) {
  var script = sqlScript.removeLicense(req.params.orgIdInt, req.params.licId);
  diagMod.debugLog('erase-license', 'SQL: ' + script);
  sql.query(script, function (err, result) {
    if (err) {
      sql.rollback(function () {
      });
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Erase License', req.query.pretty));
      sql.release();
    } else {
      doLogOnEraseLicense(req, sql, callback);
    }
  });
}

// copy the specified license entry to license-history
function doCopyLicenseToHistory(req, sql, callback) {
  var script = sqlScript.copyLicenseToHistory(req.params.orgIdInt, req.params.licId);
  diagMod.debugLog('erase-license', 'SQL: ' + script);
  sql.query(script, function (err, result) {
    if (err) {
      sql.rollback(function () {
      });
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Erase License', req.query.pretty));
      sql.release();
    } else {
      doRemoveFromLicense(req, sql, callback);
    }
  });
}

// step - perform the operations on erase license
function performEraseLicense(req, sql, callback) {
  sql.beginTransaction(function (err) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Erase License', req.query.pretty));
      sql.release();
    } else {
      doCopyLicenseToHistory(req, sql, callback);
    }
  });
}

// step - verify that license has enough remaining-points for next-cycle billing
function verifyLicenseRemainingPoints(req, sql, callback) {
  var script = sqlScript.getOrganizationRemainingPoints(req.params.orgIdInt);
  diagMod.debugLog('erase-license', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Erase License', req.query.pretty));
      sql.release();
    } else {
      script = sqlScript.deviceGetDevBudget(req.params.orgIdInt);
      diagMod.debugLog('erase-license', 'SQL: ' + script);
      sql.query(script, function (err, result) {
        if (err) {
          callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Erase License', req.query.pretty));
          sql.release();
        } else if (rows[0].totalRemainingPoints - result[0][0].budget_points < req.params.licRemainingPoints) {
          diagMod.debugLog('erase-license', 'CANNOT erase! orgTotalRemain: ' + rows[0].totalRemainingPoints + ', budget: '
          + result[0][0].budget_points + ', licenseRemain: ' + req.params.licRemainingPoints);
          callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-14', req.query.pretty));
          sql.release();
        } else {
          performEraseLicense(req, sql, callback);
        }
      });
    }
  });
}

// step - ensure license exist (ALSO retrieve remaining-points)
function checkLicenseExistence(req, sql, callback) {
  var script = sqlScript.getLicenseRemainingPoint(req.params.orgIdInt, req.params.licId);
  diagMod.debugLog('erase-license', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Erase License', req.query.pretty));
      sql.release();
    } else if (rows.length <= 0) {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponseOnLicenses('406-05', [req.params.licId], req.query.pretty));
      sql.release();
    } else if (rows[0].remaining_point <= 0) { // no points remaining
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-12', req.query.pretty));
      sql.release();
    } else {
      req.params.licRemainingPoints = rows[0].remaining_point;
      if (req.params.orgState === 'exhausted') { // 如果是Exhausted，则直接可以erase。（get_device_budget只能在Normal状态调用）
        performEraseLicense(req, sql, callback);
      } else {
        verifyLicenseRemainingPoints(req, sql, callback);
      }
    }
  });
}

// step - check organization state
function checkOrganizationState(req, sql, callback) {
  var script = sqlScript.getOrganizationState(req.params.orgId);
  diagMod.debugLog('erase-license', 'SQL: ' + script);
  sql.query(script, function (err, rows) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Erase License', req.query.pretty));
      sql.release();
    } else if (rows.length <= 0) {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-02', req.query.pretty));
      sql.release();
    } else if (rows[0].state == 'deducting') {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-10', req.query.pretty));
      sql.release();
    } else if (rows[0].state != 'normal' && rows[0].state != 'exhausted') {
      callback(ecode.code.NOT_ACCEPTABLE, ecode.errorResponse('406-13', req.query.pretty));
      sql.release();
    } else {
      req.params.orgState = rows[0].state; // 如果源Org状态是Exhausted，则可以直接erase
      req.params.orgIdInt = rows[0].id;
      checkLicenseExistence(req, sql, callback);
    }
  });
}

// perform API operation
function apiDoEraseLicense(req, callback) {
  database.pool.getConnection(function (err, sql) {
    if (err) {
      callback(ecode.code.METHOD_FAILURE, ecode.errorResponseWithPara('420-01', 'Erase License', req.query.pretty));
    } else {
      checkOrganizationState(req, sql, callback);
    }
  });
}

// API: erase license
function apiEraseLicense(req, res) {
  var startTime = new Date().getTime();
  var apiLog = {
    requestUrl: req.originalUrl,
    requestMethod: req.method,
    appId: req.user,
    requestIp: req.hostname,
    authorized: 1,
    error: 200,
    rtime: 0,
    requestParams: '',
    responseParams: ''
  };

  if (req.body.requests !== undefined) {
    apiLog.requestParams = JSON.stringify(req.body);
  }

  res.set('Content-Type', 'application/json');
  apiDoEraseLicense(req, function (errStatus, resText) {
    res.status(errStatus).end(resText);
    apiLog.rtime = new Date().getTime() - startTime;
    apiLog.error = errStatus;
    apiLog.responseParams = resText;
    utility.recordApiLog(apiLog);
  });
}

module.exports = apiEraseLicense;
