//
// API - Get the version info of License Server
//
var database = require('../lib/database');
var utility = require('../lib/utility');
var ecode = require('../lib/error-code');
var spec = require('../lib/spec');

// get server version
function apiDoGetServerVersion(req, callback) {
  callback(ecode.code.SUCCEED, utility.stringifyJsonObj({
    software_version: spec.softwareVersion,
    api_version: spec.apiVersion
  }, req.query.pretty));
}

// API: get server version
function apiServerVersion(req, res) {
  var startTime = new Date().getTime();
  var apiLog = {
    requestUrl: req.originalUrl,
    requestMethod: req.method,
    appId: '', //req.user, /* no user-auth required */
    requestIp: req.hostname,
    authorized: 1,
    error: 200,
    rtime: 0,
    requestParams: '',
    responseParams: ''
  };

  if (req.body.requests !== undefined) {
    apiLog.requestParams = JSON.stringify(req.body);
  }

  res.set('Content-Type', 'application/json');
  apiDoGetServerVersion(req, function (errStatus, resText) {
    res.status(errStatus).end(resText);
    apiLog.rtime = new Date().getTime() - startTime;
    apiLog.error = errStatus;
    apiLog.responseParams = resText;
    utility.recordApiLog(apiLog);
  });
}

module.exports = apiServerVersion;
