var database = require('../lib/database');
var ecode = require('../lib/error-code');
var sqlScript = require('../lib/sql-statements');
var logDebug = require('../lib/log');

//true--new
function createOrganization(organizationName, belongsType, belongsName, timeZone, callback) {
  database.pool.getConnection(function (err, connection) {
    if (err) {
      logDebug.errorLog("organization.js", 'POOL ==->' + err);
      callback("false", ecode.code.METHOD_FAILURE, "420-02", "Create Organization", organizationName);
    } else {
      var sql = sqlScript.getOrganizationState(organizationName);
      logDebug.debugLog("organization.js", sql);
      connection.query(sql, function (err, result) {
        if (err) {
          logDebug.errorLog("organization.js", "the sql execute error");
          connection.release();
          callback("false", ecode.code.METHOD_FAILURE, "420-01", "Create Organization", organizationName);
        } else {
          if (result.length > 0) {
            logDebug.debugLog("organization.js", "the organization is duplicated");
            connection.release();
            callback("false", ecode.code.CONFLICT, "409-01", "", organizationName);
          } else {
            sql = sqlScript.getGroupIdfromOrgGroup(belongsType, belongsName);
            logDebug.debugLog("organization.js", sql);
            connection.query(sql, function (err, result) {
              if (err) {
                logDebug.errorLog("organization.js", "the sql execute error");
                connection.release();
                callback("false", ecode.code.METHOD_FAILURE, "420-01", "Create Organization", organizationName);
              } else {
                if (result.length <= 0) {
                  logDebug.debugLog("organization.js", "the belongsType is not existed");
                  if (belongsType == 'obu') {
                    connection.release();
                    callback("false", ecode.code.NOT_ACCEPTABLE, "406-06", belongsName, organizationName);
                  } else if (belongsType == 'msp') {
                    connection.release();
                    callback("false", ecode.code.NOT_ACCEPTABLE, "406-07", belongsName, organizationName);
                  }
                } else {
                  var groupId = result[0].id;
                  connection.beginTransaction(function (err) {
                    if (err) {
                      logDebug.errorLog("organization.js", "the sql beginTransaction error");
                      connection.release();
                      callback("false", ecode.code.METHOD_FAILURE, "420-01", "Create Organization", organizationName);
                    } else {
                      sql = sqlScript.insertOrganization(groupId, organizationName, timeZone);
                      logDebug.debugLog("organization.js", sql);
                      connection.query(sql, function (err, result) {
                        if (err) {
                          connection.rollback(function () {
                            logDebug.errorLog("organization.js", "insert into organization error");
                            connection.release();
                            callback("false", ecode.code.METHOD_FAILURE, "420-01", "Create Organization", organizationName);
                          });
                        } else {
                          sql = sqlScript.insertOrganizationLog(organizationName, "exhausted", "start");
                          logDebug.debugLog("organization.js", sql);
                          connection.query(sql, function (err, result) {
                            if (err) {
                              connection.rollback(function () {
                                logDebug.errorLog("organization.js", "insert into organization_log error");
                                connection.release();
                                callback("false", ecode.code.METHOD_FAILURE, "420-01", "Create Organization", organizationName);
                              });
                            } else {
                              connection.commit(function (err) {
                                if (err) {
                                  connection.rollback(function () {
                                    logDebug.errorLog("organization.js", "create organization commit error");
                                    connection.release();
                                    callback("false", ecode.code.METHOD_FAILURE, "420-01", "Create Organization", organizationName);
                                  });
                                } else {
                                  logDebug.debugLog("organization.js", "create organization success");
                                  connection.release();
                                  callback("true");
                                }
                              });
                            }
                          });
                        }
                      });
                    }
                  });
                }
              }

            });
          }
        }

      });
    }
  });
}
function deleteOrganization(organizationName, callback) {
  database.pool.getConnection(function (err, connection) {
    if (err) {
      logDebug.errorLog("organization.js", "POOL ==->" + err);
      callback("false", ecode.code.METHOD_FAILURE, "420-02", "Delete Organization", organizationName);
    } else {
      var sql = sqlScript.getOrganizationState(organizationName);
      var organizationID;
      connection.query(sql, function (err, result) {
        if (err) {
          logDebug.errorLog("organization.js", "the sql execute error");
          connection.release();
          callback("false", ecode.code.METHOD_FAILURE, "420-01", "Delete Organization", organizationName);
        } else {
          if (result.length <= 0) {
            logDebug.debugLog("organization.js", "the organization is not existed");
            connection.release();
            callback("false", ecode.code.NOT_ACCEPTABLE, "406-02", "", organizationName);
          } else {
            organizationID = result[0].id;
            if (result[0].state == 'deducting') {
              logDebug.debugLog("organization.js", "the organization is deducting");
              connection.release();
              callback("false", ecode.code.NOT_ACCEPTABLE, "406-10", "", organizationName);
            } else if (result[0].state == 'removed') {
              logDebug.debugLog("organization.js", "the organization is removed");
              connection.release();
              callback("false", ecode.code.NOT_ACCEPTABLE, "406-02", "", organizationName);
            } else if (result[0].state != 'exhausted') {
              logDebug.debugLog("organization.js", "the organization is not exhausted Delete API");
              connection.release();
              callback("false", ecode.code.NOT_ACCEPTABLE, "406-01", "", organizationName);
            } else {
              connection.beginTransaction(function (err) {
                if (err) {
                  logDebug.errorLog("organization.js", "Delete organization:sql beginTransaction error " + organizationName);
                  connection.release();
                  callback("false", ecode.code.METHOD_FAILURE, "420-01", "Delete Organization", organizationName);
                } else {
                  sql = sqlScript.insertLicenseLogbyDeleteOrg(organizationID);
                  logDebug.debugLog("organization.js", sql);
                  connection.query(sql, function (err, result) {
                    if (err) {
                      connection.rollback(function () {
                        logDebug.errorLog("organization.js", "insert into license_log error");
                        connection.release();
                        callback("false", ecode.code.METHOD_FAILURE, "420-01", "Delete Organization", organizationName);
                      });
                    } else {
                      sql = sqlScript.insertLicenseHistorybyDeleteOrg(organizationID);
                      logDebug.debugLog("organization.js", sql);
                      connection.query(sql, function (err, result) {
                        if (err) {
                          connection.rollback(function () {
                            logDebug.errorLog("organization.js", "insert into license_history error");
                            connection.release();
                            callback("false", ecode.code.METHOD_FAILURE, "420-01", "Delete Organization", organizationName);
                          });
                        } else {
                          sql = sqlScript.deleteLicensebyDeleteOrg(organizationID);
                          logDebug.debugLog("organization.js", sql);
                          connection.query(sql, function (err, result) {
                            if (err) {
                              connection.rollback(function () {
                                logDebug.errorLog("organization.js", "delete from license error");
                                connection.release();
                                callback("false", ecode.code.METHOD_FAILURE, "420-01", "Delete Organization", organizationName);
                              });
                            } else {
                              sql = sqlScript.updateOrganizationState(organizationID, "removed");
                              logDebug.debugLog("organization.js", sql);
                              connection.query(sql, function (err, result) {
                                if (err) {
                                  connection.rollback(function () {
                                    logDebug.errorLog("organization.js", "update organization error");
                                    connection.release();
                                    callback("false", ecode.code.METHOD_FAILURE, "420-01", "Delete Organization", organizationName);
                                  });
                                } else {
                                  sql = sqlScript.insertOrganizationLogbyId(organizationID, "removed", "remove organization");
                                  logDebug.debugLog("organization.js", sql);
                                  connection.query(sql, function (err, result) {
                                    if (err) {
                                      connection.rollback(function () {
                                        logDebug.errorLog("organization.js", "update organization error");
                                        connection.release();
                                        callback("false", ecode.code.METHOD_FAILURE, "420-01", "Delete Organization", organizationName);
                                      });
                                    } else {
                                      connection.commit(function (err) {
                                        if (err) {
                                          connection.rollback(function () {
                                            logDebug.errorLog("organization.js", "delete organization commit error");
                                            connection.release();
                                            callback("false", ecode.code.METHOD_FAILURE, "420-01", "Delete Organization", organizationName);
                                          });
                                        } else {
                                          logDebug.debugLog("organization.js", "Delete organization success");
                                          connection.release();
                                          callback("true");
                                        }
                                      });
                                    }
                                  })
                                }
                              })
                            }
                          });
                        }
                      });
                    }
                  });
                }
              });
            }
          }
        }
      });
    }
  });
}

function activeOrganization(organizationName, callback) {
  database.pool.getConnection(function (err, connection) {
    if (err) {
      logDebug.errorLog("organization.js", "POOL ==->" + err);
      callback("false", ecode.code.METHOD_FAILURE, "420-02", "Active Organization", organizationName);
    } else {
      var organizationID, points, expensePoints;
      var sql = sqlScript.getOrganizationState(organizationName);
      logDebug.debugLog("organization.js", sql);
      connection.query(sql, function (err, result) {
        if (err) {
          logDebug.errorLog("organization.js", "the sql execute error");
          connection.release();
          callback("false", ecode.code.METHOD_FAILURE, "420-01", "Active Organization", organizationName);
        } else {
          if (result.length <= 0) {
            logDebug.debugLog("organization.js", "the organization is not existed");
            connection.release();
            callback("false", ecode.code.NOT_ACCEPTABLE, "406-02", "", organizationName);
          } else {
            organizationID = result[0].id;
            if (result[0].state == 'deducting') {
              logDebug.debugLog("organization.js", "the organization is deducting");
              connection.release();
              callback("false", ecode.code.NOT_ACCEPTABLE, "406-10", "", organizationName);
            } else if (result[0].state != 'exhausted') {
              logDebug.debugLog("organization.js", "the organization is not exhausted Active API");
              connection.release();
              callback("false", ecode.code.NOT_ACCEPTABLE, "406-01", "", organizationName);
            } else {
              sql = sqlScript.getRemainPointsforOrg(organizationID);
              logDebug.debugLog("organization.js", sql);
              connection.query(sql, function (err, result) {
                if (err) {
                  logDebug.errorLog("organization.js", "select remain points error");
                  connection.release();
                  callback("false", ecode.code.METHOD_FAILURE, "420-01", "Active Organization", organizationName);
                } else {
                  points = result[0].points;
                  if (points <= 0) {
                    logDebug.debugLog("organization.js", "remain points is zero" + points);
                    connection.release();
                    callback("false", ecode.code.NOT_ACCEPTABLE, "406-03", "normal", organizationName);
                  } else {
                    sql = sqlScript.getExpensePointsforOrg(organizationID);
                    logDebug.debugLog("organization.js", sql);
                    connection.query(sql, function (err, result) {
                      if (err) {
                        logDebug.errorLog("organization.js", "select budget_point_device_all_time error");
                        connection.release();
                        callback("false", ecode.code.METHOD_FAILURE, "420-01", "Active Organization", organizationName);
                      } else {
                        expensePoints = result[0].expensePoints;
                        if ((points - expensePoints) < 0) {
                          logDebug.debugLog("organization.js", "budget_point_device_all_time points not enough");
                          connection.release();
                          callback("false", ecode.code.NOT_ACCEPTABLE, "406-14", "Active Organization", organizationName);
                        } else {
                          connection.beginTransaction(function (err) {
                            if (err) {
                              logDebug.errorLog("organization.js", "active organization: sql beginTransaction error " + organizationName);
                              connection.release();
                              callback("false", ecode.code.METHOD_FAILURE, "420-01", "Active Organization", organizationName);
                            } else {
                              sql = sqlScript.activeOrganization(organizationID);
                              logDebug.debugLog("organization.js", sql);
                              connection.query(sql, function (err, result) {
                                if (err) {
                                  connection.rollback(function () {
                                    logDebug.errorLog("organization.js", "update organization error " + organizationName);
                                    connection.release();
                                    callback("false", ecode.code.METHOD_FAILURE, "420-01", "Active Organization", organizationName);
                                  });
                                } else {
                                  sql = sqlScript.insertOrganizationLogbyId(organizationID, "normal", "active organization");
                                  logDebug.debugLog("organization.js", sql);
                                  connection.query(sql, function (err, result) {
                                    if (err) {
                                      connection.rollback(function () {
                                        logDebug.errorLog("organization.js", "insert_into organization_log error " + organizationName);
                                        connection.release();
                                        callback("false", ecode.code.METHOD_FAILURE, "420-01", "Active Organization", organizationName);
                                      });
                                    } else {
                                      connection.commit(function (err) {
                                        if (err) {
                                          connection.rollback(function () {
                                            logDebug.errorLog("organization.js", "active organization commit error");
                                            connection.release();
                                            callback("false", ecode.code.METHOD_FAILURE, "420-01", "Active Organization", organizationName);
                                          });
                                        } else {
                                          logDebug.debugLog("organization.js", "active organization success");
                                          connection.release();
                                          callback("true");
                                        }
                                      });
                                    }
                                  });
                                }
                              });
                            }
                          });
                        }
                      }
                    });
                  }
                }
              });
            }
          }
        }
      });
    }
  });
}
function updateOrganization(organizationName, timeZone, callback) {
  database.pool.getConnection(function (err, connection) {
    if (err) {
      logDebug.errorLog("organization.js", "POOL ==->" + err);
      callback("false", ecode.code.METHOD_FAILURE, "420-02", "Update Organization", organizationName);
    } else {
      var organizationID;
      var organizationState;
      var sql = sqlScript.getOrganizationState(organizationName);
      connection.query(sql, function (err, result) {
        if (err) {
          logDebug.errorLog("organization.js", "the sql execute error");
          connection.release();
          callback("false", ecode.code.METHOD_FAILURE, "420-01", "Update Organization", organizationName);
        } else {
          if (result.length <= 0) {
            logDebug.debugLog("organization.js", "the organization is not existed");
            connection.release();
            callback("false", ecode.code.NOT_ACCEPTABLE, "406-02", "", organizationName);
          } else {
            organizationID = result[0].id;
            organizationState = result[0].state;
            if (result[0].state == 'deducting') {
              logDebug.debugLog("organization.js", "the organization is deducting");
              connection.release();
              callback("false", ecode.code.NOT_ACCEPTABLE, "406-10", "", organizationName);
            } else if (result[0].state == 'removed') {
              logDebug.debugLog("organization.js", "the organization is removed:" + organizationName);
              connection.release();
              callback("false", ecode.code.NOT_ACCEPTABLE, "406-02", "", organizationName);
            } else {
              connection.beginTransaction(function (err) {
                if (err) {
                  logDebug.errorLog("organization.js", "update organization: sql beginTransaction error " + organizationName);
                  connection.release();
                  callback("false", ecode.code.METHOD_FAILURE, "420-01", "Update Organization", organizationName);
                } else {
                  sql = sqlScript.updateOrganizationTimeZone(organizationID, timeZone);
                  logDebug.debugLog("organization.js", sql);
                  connection.query(sql, function (err, result) {
                    if (err) {
                      connection.rollback(function () {
                        logDebug.errorLog("organization.js", "update organization time_zone error " + organizationName);
                        connection.release();
                        callback("false", ecode.code.METHOD_FAILURE, "420-01", "Update Organization", organizationName);
                      });
                    } else {
                      sql = sqlScript.insertOrganizationLogbyId(organizationID, organizationState, "update time_zone");
                      logDebug.debugLog("organization.js", sql);
                      connection.query(sql, function (err, result) {
                        if (err) {
                          connection.rollback(function () {
                            logDebug.errorLog("organization.js", "insert into organization_log error " + organizationName);
                            connection.release();
                            callback("false", ecode.code.METHOD_FAILURE, "420-01", "Update Organization", organizationName);
                          });
                        } else {
                          connection.commit(function (err) {
                            if (err) {
                              connection.rollback(function () {
                                logDebug.errorLog("organization.js", "update organization commit error");
                                connection.release();
                                callback("false", ecode.code.METHOD_FAILURE, "420-01", "Update Organization", organizationName);
                              });
                            } else {
                              logDebug.debugLog("organization.js", "update organization success");
                              connection.release();
                              callback("true");
                            }
                          });
                        }
                      });
                    }
                  });
                }
              });
            }
          }
        }
      });
    }
  });
}

function getOrganizationInfo(organizationName, callback) {
  database.pool.getConnection(function (err, connection) {
    if (err) {
      logDebug.errorLog("organization.js", "POOL get organization info==->" + err);
      callback("false", ecode.code.METHOD_FAILURE, "420-01", "Get Organization Information", organizationName);
    } else {
      var sql = sqlScript.getOrganizationStateTimezone(organizationName);
      logDebug.debugLog("organization.js", sql);
      connection.query(sql, function (err, result) {
        if (err) {
          logDebug.errorLog("organization.js", "the sql execute error");
          connection.release();
          callback("false", ecode.code.METHOD_FAILURE, "420-01", "Get Organization Information", organizationName);
        } else {
          var organizationID, timeZone, points, expensePerUnit, cycle, organizationState, expiration;
          if (result.length <= 0) {
            logDebug.debugLog("organization.js", "the organization is not existed");
            connection.release();
            callback("false", ecode.code.NOT_ACCEPTABLE, "406-02", "", organizationName);
          } else {
            organizationID = result[0].id;
            timeZone = result[0].time_zone;
            organizationState = result[0].state;
            if (result[0].state == 'deducting') {
              logDebug.debugLog("organization.js", "the organization is deducting:" + organizationName);
              connection.release();
              callback("false", ecode.code.NOT_ACCEPTABLE, "406-10", "", organizationName);
            } else if (result[0].state == 'removed') {
              logDebug.debugLog("organization.js", "the organization is removed:" + organizationName);
              connection.release();
              callback("false", ecode.code.NOT_ACCEPTABLE, "406-02", "", organizationName);
            } else {
              sql = sqlScript.getRemainPointsforOrg(organizationID);
              logDebug.debugLog("organization.js", sql);
              connection.query(sql, function (err, result) {
                if (err) {
                  logDebug.errorLog("organization.js", "the sql execute error");
                  connection.release();
                  callback("false", ecode.code.METHOD_FAILURE, "420-01", "Get Organization Information", organizationName);
                } else {
                  points = result[0].points;
                  sql = sqlScript.getExpensePointsforOrg(organizationID);
                  logDebug.debugLog("organization.js", sql);
                  connection.query(sql, function (err, result) {
                    if (err) {
                      logDebug.errorLog("organization.js", "the sql execute error");
                      connection.release();
                      callback("false", ecode.code.METHOD_FAILURE, "420-01", "Get Organization Information", organizationName);
                    } else {
                      expensePerUnit = result[0].expensePoints;
                      if (expensePerUnit == 0) {
                        expiration = "";
                      } else {
                        expiration = parseInt(points / expensePerUnit);
                        if (organizationState == "normal" && expiration == 0) {
                          expiration = 1;
                        }
                      }
                      sql = sqlScript.getBillingCycle(organizationID);
                      logDebug.debugLog("organization.js", sql);
                      connection.query(sql, function (err, result) {
                        if (err) {
                          logDebug.errorLog("organization.js", "the sql execute error");
                          connection.release();
                          callback("false", ecode.code.METHOD_FAILURE, "420-01", "Get Organization Information", organizationName);
                        } else {
                          cycle = result[0].cycle;
                          var resJson = {
                            "organization": {
                              "points": points,
                              "expense_per_unit": expensePerUnit,
                              "unit": cycle,
                              "expiration": expiration,
                              "state": organizationState,
                              "time_zone": timeZone
                            }
                          };
                          logDebug.debugLog("organization.js", JSON.stringify(resJson));
                          connection.release();
                          callback("true", ecode.code.SUCCEED, resJson);
                        }
                      });
                    }
                  });
                }
              });
            }
          }
        }
      });
    }
  });
}
module.exports.createOrganization = createOrganization;
module.exports.deleteOrganization = deleteOrganization;
module.exports.activeOrganization = activeOrganization;
module.exports.updateOrganization = updateOrganization;
module.exports.getOrganizationInfo = getOrganizationInfo;