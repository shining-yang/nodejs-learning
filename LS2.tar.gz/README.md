# License-Server 2

## General Information

License-Server is the application which design for license activation and billing for bizcloud project.

## Prerequisites

* Node.js v0.12.0 from [http://nodejs.org/download/](http://nodejs.org/download/ "Download Node.js") 
(Hint: 'npm' should have also been included in this package)

* MySQL 5.6 from [http://dev.mysql.com/](http://dev.mysql.com/ "Visit mysql web site")

	* Windows
	
		Download mysql setup package and then follow the setup instructions to install mysql.

	* Linux
		    
		    sudo apt-get install mysql-server (Ubuntu, etc)
		    sudo yum install mysql-server (CentOS, etc)
		    
## Get Sources
* Download the source tarball from [here](https://github.com/d-link/License-Server/releases "License Server 2")

## Initialize Database (REQUIRED only at first time)
Execute the following sql script files in mysql. E.g. Issue the following commands in mysql command line utility.

    source ./sql/license_schema_empty.sql
    source ./sql/license_schema_initial_data.sql
    source ./sql/license_procedure.sql

## Configure to Connect MySQL Database
You should review the file `config/database.json` which provides several options used to connect MySQL, and modify it if necessary, to make License Server access MySQL correctly. This file contains several groups of options for different scenarios such as `development`, `test` and `production`. For example, you can change the options for you production environment and then launch License Server with argument like this: `NODE_ENV="production" ./bin/www`. The following is a pre-defined sample and you should change it to meet your needs.

    {
      "development": {
        "dbHost": "172.18.190.138",
        "dbPort": 3306,
        "dbName": "license",
        "dbUser": "license",
        "dbPassword": "111111",
        "acquireTimeout": 10000,
        "waitForConnections": true,
        "connectionLimit": 10,
        "queueLimit": 0
      },
      "test": {
        "dbHost": "172.18.190.39",
        "dbPort": 3306,
        "dbName": "license",
        "dbUser": "root",
        "dbPassword": "cc",
        "acquireTimeout": 10000,
        "waitForConnections": true,
        "connectionLimit": 10,
        "queueLimit": 0
      },
      "production": {
        "dbHost": "localhost",
        "dbPort": 3306,
        "dbName": "license",
        "dbUser": "license",
        "dbPassword": "111111",
        "acquireTimeout": 10000,
        "waitForConnections": true,
        "connectionLimit": 10,
        "queueLimit": 0
      }
    }

## Run License Server

1. Enter the source code directory.

    cd src

2. Install required packages. This is REQUIRED only when you haven't done it before.

    npm install

3. Run it.

    ./bin/www
